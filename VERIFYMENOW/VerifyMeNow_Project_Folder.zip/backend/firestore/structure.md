# Firestore Collections
- users
- verifications
- payments