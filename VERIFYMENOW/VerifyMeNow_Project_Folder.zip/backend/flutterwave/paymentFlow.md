# Flutterwave Integration
1. Collect payment
2. Redirect to Flutterwave
3. Webhook verifies transaction
4. Unlock verification access