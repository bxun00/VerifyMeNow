import { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// Simple user type
export interface User {
  id: string;
  email: string;
  isAdmin: boolean;
}

// Create a simple context
const AuthContext = createContext({
  user: null as User | null,
  isAuthenticated: false,
  isLoading: true,
  login: async (_email: string, _password: string) => false,
  logout: () => {},
  error: null as string | null
});

// Auth provider component
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load user on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('verifyme_user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        console.error('Failed to parse user data');
      }
    }
    setIsLoading(false);
  }, []);

  // Simple login function
  const login = async (email: string, _password: string) => {
    try {
      const mockUser = {
        id: `user_${Date.now()}`,
        email,
        isAdmin: email.includes('admin')
      };
      
      localStorage.setItem('verifyme_user', JSON.stringify(mockUser));
      setUser(mockUser);
      return true;
    } catch (e) {
      setError('Login failed');
      return false;
    }
  };

  // Simple logout function
  const logout = () => {
    localStorage.removeItem('verifyme_user');
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
        error
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// Simple auth hook
export function useAuth() {
  return useContext(AuthContext);
}

// Simple protected route hook
export function useRequireAuth(redirectTo = '/login') {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate(redirectTo);
    }
  }, [isAuthenticated, isLoading, navigate, redirectTo]);

  return { isLoading };
}