import { FOOTER_LINKS, SOCIAL_LINKS } from "@/lib/constants";
import { Icons } from "@/components/icons";
import { Separator } from "@/components/ui/separator";

export function Footer() {
  return (
    <footer className="bg-slate-50 border-t border-slate-200 pt-12 pb-8">
      <div className="container px-4 md:px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <Icons.Logo className="h-6 w-6 text-blue-600" />
              <span className="font-bold text-lg">VerifyMeNow</span>
            </div>
            <p className="text-sm text-slate-600 mb-4">
              Verify Anyone. Instantly. Affordably.
              Secure digital identity verification for individuals and businesses.
            </p>
            <div className="flex space-x-4">
              {SOCIAL_LINKS.map((social, index) => {
                const Icon = Icons[social.icon as keyof typeof Icons];
                return (
                  <a
                    key={index}
                    href={social.url}
                    className="text-slate-600 hover:text-blue-600 transition-colors"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Icon className="h-5 w-5" />
                  </a>
                );
              })}
            </div>
          </div>
          
          {FOOTER_LINKS.map((section, index) => (
            <div key={index} className="space-y-4">
              <h4 className="font-semibold text-sm text-slate-900">{section.title}</h4>
              <ul className="space-y-3">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href={link.href}
                      className="text-sm text-slate-600 hover:text-blue-600 transition-colors"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        <Separator className="my-8" />
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-600">
            © {new Date().getFullYear()} VerifyMeNow. All rights reserved.
          </p>
          <div className="flex gap-4">
            <a href="#terms" className="text-xs text-slate-600 hover:text-blue-600 transition-colors">
              Terms
            </a>
            <a href="#privacy" className="text-xs text-slate-600 hover:text-blue-600 transition-colors">
              Privacy
            </a>
            <a href="#cookies" className="text-xs text-slate-600 hover:text-blue-600 transition-colors">
              Cookies
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}