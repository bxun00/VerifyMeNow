import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';

// Simple user type
export interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  isAdmin: boolean;
}

// Auth context type
interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  error: string | null;
}

// Create context with default values
const defaultContext: AuthContextType = {
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => false,
  register: async () => false,
  logout: () => {},
  error: null
};

// Create auth context
export const AuthContext = createContext<AuthContextType>(defaultContext);

// Auth hook
export function useAuth(): AuthContextType {
  return useContext(AuthContext);
}

// Protected route hook
export function useRequireAuth(redirectTo = '/login') {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();
  
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate(redirectTo);
    }
  }, [isAuthenticated, isLoading, navigate, redirectTo]);
  
  return { isLoading };
}

// Create a function that returns the context value
export function createAuthContextValue() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Load user on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('verifyme_user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        console.error('Failed to parse user data');
      }
    }
    setIsLoading(false);
  }, []);
  
  // Login function
  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Mock API call
      await new Promise(r => setTimeout(r, 1000));
      
      // Create mock user
      const isAdmin = email.includes('admin');
      const mockUser = {
        id: `user_${Date.now()}`,
        email,
        name: email.split('@')[0],
        role: isAdmin ? 'admin' : 'user',
        isAdmin
      };
      
      localStorage.setItem('verifyme_user', JSON.stringify(mockUser));
      setUser(mockUser);
      return true;
    } catch (e) {
      setError('Login failed');
      return false;
    } finally {
      setIsLoading(false);
    }
  };
  
  // Register function
  const register = async (name: string, email: string, password: string) => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Mock API call
      await new Promise(r => setTimeout(r, 1000));
      
      // Create mock user
      const isAdmin = email.includes('admin');
      const mockUser = {
        id: `user_${Date.now()}`,
        email,
        name,
        role: isAdmin ? 'admin' : 'user',
        isAdmin
      };
      
      localStorage.setItem('verifyme_user', JSON.stringify(mockUser));
      setUser(mockUser);
      return true;
    } catch (e) {
      setError('Registration failed');
      return false;
    } finally {
      setIsLoading(false);
    }
  };
  
  // Logout function
  const logout = () => {
    localStorage.removeItem('verifyme_user');
    setUser(null);
  };
  
  return {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    register,
    logout,
    error
  };
}