import { ReactNode, useEffect, useState } from 'react';
import { AuthContext, User } from '@/lib/auth';

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Load user on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('verifyme_user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        console.error('Failed to parse user data');
      }
    }
    setIsLoading(false);
  }, []);
  
  // Login function
  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Mock API call
      await new Promise(r => setTimeout(r, 1000));
      
      // Create mock user
      const isAdmin = email.includes('admin');
      const mockUser = {
        id: `user_${Date.now()}`,
        email,
        name: email.split('@')[0],
        role: isAdmin ? 'admin' : 'user',
        isAdmin
      };
      
      localStorage.setItem('verifyme_user', JSON.stringify(mockUser));
      setUser(mockUser);
      return true;
    } catch (e) {
      setError('Login failed');
      return false;
    } finally {
      setIsLoading(false);
    }
  };
  
  // Register function
  const register = async (name: string, email: string, password: string) => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Mock API call
      await new Promise(r => setTimeout(r, 1000));
      
      // Create mock user
      const isAdmin = email.includes('admin');
      const mockUser = {
        id: `user_${Date.now()}`,
        email,
        name,
        role: isAdmin ? 'admin' : 'user',
        isAdmin
      };
      
      localStorage.setItem('verifyme_user', JSON.stringify(mockUser));
      setUser(mockUser);
      return true;
    } catch (e) {
      setError('Registration failed');
      return false;
    } finally {
      setIsLoading(false);
    }
  };
  
  // Logout function
  const logout = () => {
    localStorage.removeItem('verifyme_user');
    setUser(null);
  };
  
  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        register,
        logout,
        error
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}