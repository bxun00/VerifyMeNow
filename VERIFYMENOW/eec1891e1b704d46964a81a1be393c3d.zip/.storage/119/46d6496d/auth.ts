import { createContext, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// Simple user type
export interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  isAdmin: boolean;
}

// Auth context type
interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  error: string | null;
}

// Create context with default values
const defaultContext: AuthContextType = {
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => false,
  register: async () => false,
  logout: () => {},
  error: null
};

// Create auth context
export const AuthContext = createContext<AuthContextType>(defaultContext);

// Auth hook
export function useAuth(): AuthContextType {
  return useContext(AuthContext);
}

// Protected route hook
export function useRequireAuth(redirectTo = '/login') {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();
  
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate(redirectTo);
    }
  }, [isAuthenticated, isLoading, navigate, redirectTo]);
  
  return { isLoading };
}