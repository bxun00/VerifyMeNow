import { Button } from "@/components/ui/button";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-white to-blue-50 py-20 md:py-32">
      {/* Background Pattern */}
      <div className="absolute inset-0 z-0 opacity-20">
        <div className="absolute right-0 bottom-0 w-full h-full bg-grid-blue-500/[0.2] [mask-image:linear-gradient(to_bottom_left,white,transparent)]"></div>
      </div>
      
      {/* Content */}
      <div className="container relative z-10 px-4 md:px-6">
        <div className="mx-auto max-w-4xl text-center">
          <h1 className="animate-in slide-in-from-bottom-4 duration-700 font-extrabold tracking-tight text-4xl sm:text-5xl md:text-6xl bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-blue-900">
            Verify Anyone.<br /> Instantly. Affordably.
          </h1>
          <p className="mt-6 animate-in slide-in-from-bottom-5 duration-700 delay-150 text-xl text-slate-600 max-w-2xl mx-auto">
            Streamline your verification process with our powerful AI-driven platform. Save time, reduce fraud, and make confident decisions.
          </p>
          <div className="mt-10 animate-in slide-in-from-bottom-6 duration-700 delay-300 flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-base px-8 py-6 rounded-full shadow-blue-500/30 shadow-lg hover:shadow-blue-500/40 hover:shadow-xl transition-all">
              Get Started
            </Button>
            <Button variant="outline" size="lg" className="text-base px-8 py-6 rounded-full">
              How It Works
            </Button>
          </div>
        </div>

        {/* Floating shield/security elements */}
        <div className="absolute left-1/4 -translate-x-1/2 top-1/4 animate-float-slow opacity-30 hidden lg:block">
          <div className="w-20 h-20 rounded-full border-2 border-blue-300/50"></div>
        </div>
        <div className="absolute right-1/4 translate-x-1/2 bottom-1/4 animate-float-slow-reverse opacity-30 hidden lg:block">
          <div className="w-16 h-16 rounded-full border-2 border-blue-300/50"></div>
        </div>
      </div>
    </section>
  );
}