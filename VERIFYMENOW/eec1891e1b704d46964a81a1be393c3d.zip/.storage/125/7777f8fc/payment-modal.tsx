import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { Icons } from "../icons";
import { mockStripePayment, formatCardNumber, detectCardType } from "./stripe-integration";
import { VisaLogo, MastercardLogo, AmexLogo, DiscoverLogo } from "./card-logos";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  planName: string;
  planPrice: string;
}

export function PaymentModal({
  isOpen,
  onClose,
  planName,
  planPrice,
}: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState("credit-card");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvc, setCardCvc] = useState("");
  const [cardName, setCardName] = useState("");
  const [cardType, setCardType] = useState("");
  const [error, setError] = useState("");

  // Format card number as it's entered
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = formatCardNumber(e.target.value);
    setCardNumber(value);
    const type = detectCardType(value);
    setCardType(type);
  };

  // Format expiry date as it's entered
  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '');
    if (value.length <= 2) {
      setCardExpiry(value);
    } else {
      setCardExpiry(`${value.slice(0, 2)}/${value.slice(2, 4)}`);
    }
  };

  // Reset form when closing
  useEffect(() => {
    if (!isOpen) {
      setCardNumber("");
      setCardExpiry("");
      setCardCvc("");
      setCardName("");
      setError("");
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsSubmitting(true);

    try {
      if (paymentMethod === "credit-card") {
        const response = await mockStripePayment({
          cardNumber,
          expiry: cardExpiry,
          cvc: cardCvc,
          name: cardName,
          planName,
          planPrice,
        });

        // Create success message with card info
        const cardBrand = response.cardType === 'visa' ? 'Visa' : 
                         response.cardType === 'mastercard' ? 'Mastercard' : 
                         response.cardType === 'amex' ? 'American Express' : 'Card';

        toast.success("Payment received! Thank you for your subscription.", {
          description: `Your ${planName} plan is now active. Charged to ${cardBrand} ending in ${response.last4}.`,
          duration: 5000,
        });
      } else {
        // PayPal flow would redirect in real implementation
        toast.success("PayPal payment completed successfully!", {
          description: `Your ${planName} plan is now active.`,
          duration: 5000,
        });
      }

      onClose();
    } catch (err: Error | unknown) {
      setError(err instanceof Error ? err.message : "Payment failed. Please try again.");
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Subscribe to {planName}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Plan</Label>
              <span className="font-medium">{planName}</span>
            </div>
            <div className="flex justify-between">
              <Label>Price</Label>
              <span className="font-medium">${planPrice}/mo</span>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Payment Method</Label>
            <RadioGroup
              defaultValue="credit-card"
              value={paymentMethod}
              onValueChange={setPaymentMethod}
              className="grid grid-cols-2 gap-4"
            >
              <div className={`flex items-center space-x-2 border rounded-md p-3 cursor-pointer hover:bg-slate-50 ${paymentMethod === 'credit-card' ? 'border-blue-600 bg-blue-50' : ''}`}>
                <RadioGroupItem value="credit-card" id="credit-card" />
                <Label htmlFor="credit-card" className="flex items-center cursor-pointer">
                  <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect width="20" height="14" x="2" y="5" rx="2" stroke="currentColor" strokeWidth="2" />
                    <path d="M2 10H22" stroke="currentColor" strokeWidth="2" />
                  </svg>
                  Credit/Debit Card
                </Label>
              </div>
              <div className={`flex items-center space-x-2 border rounded-md p-3 cursor-pointer hover:bg-slate-50 ${paymentMethod === 'paypal' ? 'border-blue-600 bg-blue-50' : ''}`}>
                <RadioGroupItem value="paypal" id="paypal" />
                <Label htmlFor="paypal" className="flex items-center cursor-pointer">
                  <svg className="h-5 w-5 mr-2 text-blue-600" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19.0803 6.10872C19.2539 5.31237 19.0803 4.76279 18.6532 4.31532C18.1828 3.77982 17.3285 3.5 16.2639 3.5H11.5745C11.36 3.5 11.1455 3.66684 11.0954 3.86776L9.20359 14.8197C9.20359 15.0206 9.32824 15.1875 9.54269 15.1875H11.8825L11.7078 16.2668C11.6578 16.4677 11.7824 16.6346 11.997 16.6346H14.0136C14.2281 16.6346 14.4427 16.4677 14.4427 16.2668V16.1838L15.2003 11.6077V11.5246C15.2003 11.3238 15.4149 11.1569 15.6294 11.1569H15.9305C17.8278 11.1569 19.3232 10.4274 19.8837 8.28481C20.1848 7.30603 20.0936 6.49148 19.6164 5.96012C19.4853 5.7593 19.3151 5.5986 19.0803 5.53187" stroke="currentColor" strokeWidth="1.5"/>
                    <path d="M18.3066 5.56489C18.2677 5.55212 18.2269 5.53996 18.1848 5.52847C18.1427 5.51699 18.1 5.50599 18.0565 5.49556C17.7668 5.43756 17.4516 5.41066 17.1216 5.41066H13.6265C13.5511 5.41066 13.4789 5.43138 13.4177 5.46783C13.2904 5.54374 13.2005 5.68578 13.1741 5.85784L12.5 10.0736L12.4375 10.4029C12.4854 10.1167 12.7318 9.92268 13.0187 9.92268H14.2524C16.4745 9.92268 18.1759 9.04181 18.8244 6.48724C18.8466 6.39847 18.8658 6.31265 18.8829 6.2295C18.7564 6.0233 18.5905 5.85784 18.3832 5.72775C18.3589 5.67226 18.3328 5.61749 18.3066 5.56489Z" stroke="currentColor" strokeWidth="1.5"/>
                    <path d="M13.1742 5.85767C13.2007 5.68561 13.2905 5.54356 13.4179 5.46775C13.4791 5.4313 13.5513 5.41058 13.6266 5.41058H17.1217C17.4518 5.41058 17.767 5.43748 18.0566 5.49549C18.1001 5.50591 18.1428 5.51691 18.1849 5.52839C18.227 5.53988 18.2679 5.55204 18.3068 5.56482C18.3329 5.61742 18.359 5.67219 18.3834 5.72767C18.5906 5.85767 18.7565 6.02322 18.883 6.22933C18.9755 7.10342 18.8599 7.82436 18.4481 8.34786C17.9174 8.97967 17.0077 9.27945 15.8667 9.27945H14.7855C14.4852 9.27945 14.2351 9.53029 14.185 9.82973L13.6349 13.0704L13.4179 14.1819C13.4179 14.3138 13.5078 14.4458 13.6266 14.4458H15.4484C15.6355 14.4458 15.8057 14.3139 15.8557 14.1322V14.0924L16.3089 11.3198V11.27C16.3089 11.0884 16.4789 10.9563 16.6661 10.9563H16.882C17.8164 10.9563 18.591 10.7249 19.0528 10.2622C19.5646 9.76958 19.7498 9.10694 19.6599 8.34786C19.5784 7.3041 19.0347 6.51435 18.2432 6.06232" stroke="currentColor" strokeWidth="1.5"/>
                  </svg>
                  PayPal
                </Label>
              </div>
            </RadioGroup>
          </div>

          {paymentMethod === "credit-card" && (
            <div className="space-y-4">
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-2 rounded-md text-sm">
                  {error}
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="card-number">Card Number</Label>
                <div className="relative">
                  <Input 
                    id="card-number" 
                    placeholder="1234 5678 9012 3456" 
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    required 
                    className="pr-10"
                    maxLength={19}
                  />
                  {cardType === 'visa' && (
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-blue-600 font-semibold">
                      VISA
                    </span>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input 
                    id="expiry" 
                    placeholder="MM/YY" 
                    value={cardExpiry}
                    onChange={handleExpiryChange}
                    required 
                    maxLength={5}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cvc">CVC</Label>
                  <Input 
                    id="cvc" 
                    placeholder="123" 
                    value={cardCvc}
                    onChange={(e) => setCardCvc(e.target.value.replace(/\D/g, '').substring(0, 4))}
                    required 
                    maxLength={4}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">Name on Card</Label>
                <Input 
                  id="name" 
                  placeholder="John Doe" 
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value)}
                  required 
                />
              </div>
            </div>
          )}

          {paymentMethod === "paypal" && (
            <div className="text-center py-6">
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-2 rounded-md text-sm mb-4">
                  {error}
                </div>
              )}
              <div className="border rounded-lg p-6 bg-blue-50 mb-4">
                <p className="text-sm text-blue-800 mb-4">
                  You'll be redirected to PayPal to complete your payment securely
                </p>
                <svg
                  className="w-16 h-16 mx-auto text-blue-600"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M19.0803 6.10872C19.2539 5.31237 19.0803 4.76279 18.6532 4.31532C18.1828 3.77982 17.3285 3.5 16.2639 3.5H11.5745C11.36 3.5 11.1455 3.66684 11.0954 3.86776L9.20359 14.8197C9.20359 15.0206 9.32824 15.1875 9.54269 15.1875H11.8825L11.7078 16.2668C11.6578 16.4677 11.7824 16.6346 11.997 16.6346H14.0136C14.2281 16.6346 14.4427 16.4677 14.4427 16.2668V16.1838L15.2003 11.6077V11.5246C15.2003 11.3238 15.4149 11.1569 15.6294 11.1569H15.9305C17.8278 11.1569 19.3232 10.4274 19.8837 8.28481C20.1848 7.30603 20.0936 6.49148 19.6164 5.96012C19.4853 5.7593 19.3151 5.5986 19.0803 5.53187"
                    stroke="currentColor"
                    strokeWidth="2"
                    fill="rgba(25, 118, 210, 0.1)"
                  />
                  <path
                    d="M18.3066 5.56489C18.2677 5.55212 18.2269 5.53996 18.1848 5.52847C18.1427 5.51699 18.1 5.50599 18.0565 5.49556C17.7668 5.43756 17.4516 5.41066 17.1216 5.41066H13.6265C13.5511 5.41066 13.4789 5.43138 13.4177 5.46783C13.2904 5.54374 13.2005 5.68578 13.1741 5.85784L12.5 10.0736L12.4375 10.4029C12.4854 10.1167 12.7318 9.92268 13.0187 9.92268H14.2524C16.4745 9.92268 18.1759 9.04181 18.8244 6.48724C18.8466 6.39847 18.8658 6.31265 18.8829 6.2295C18.7564 6.0233 18.5905 5.85784 18.3832 5.72775C18.3589 5.67226 18.3328 5.61749 18.3066 5.56489Z"
                    stroke="currentColor"
                    strokeWidth="2"
                    fill="rgba(25, 118, 210, 0.05)"
                  />
                  <path
                    d="M13.1742 5.85767C13.2007 5.68561 13.2905 5.54356 13.4179 5.46775C13.4791 5.4313 13.5513 5.41058 13.6266 5.41058H17.1217C17.4518 5.41058 17.767 5.43748 18.0566 5.49549C18.1001 5.50591 18.1428 5.51691 18.1849 5.52839C18.227 5.53988 18.2679 5.55204 18.3068 5.56482C18.3329 5.61742 18.359 5.67219 18.3834 5.72767C18.5906 5.85767 18.7565 6.02322 18.883 6.22933C18.9755 7.10342 18.8599 7.82436 18.4481 8.34786C17.9174 8.97967 17.0077 9.27945 15.8667 9.27945H14.7855C14.4852 9.27945 14.2351 9.53029 14.185 9.82973L13.6349 13.0704L13.4179 14.1819C13.4179 14.3138 13.5078 14.4458 13.6266 14.4458H15.4484C15.6355 14.4458 15.8057 14.3139 15.8557 14.1322V14.0924L16.3089 11.3198V11.27C16.3089 11.0884 16.4789 10.9563 16.6661 10.9563H16.882C17.8164 10.9563 18.591 10.7249 19.0528 10.2622C19.5646 9.76958 19.7498 9.10694 19.6599 8.34786C19.5784 7.3041 19.0347 6.51435 18.2432 6.06232"
                    stroke="currentColor"
                    strokeWidth="2"
                    fill="rgba(25, 118, 210, 0.05)"
                  />
                </svg>
              </div>
              <p className="text-xs text-slate-500">By clicking "Pay Now", you'll be redirected to PayPal to complete your purchase securely</p>
            </div>
          )}

          <DialogFooter>
            <div className="flex flex-col w-full space-y-2">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-slate-600">Payment Methods:</span>
                <div className="flex space-x-2">
                  <VisaLogo className="h-8 w-auto" active={cardType === 'visa'} />
                  <MastercardLogo className="h-8 w-auto" active={cardType === 'mastercard'} />
                  <AmexLogo className="h-8 w-auto" active={cardType === 'amex'} />
                  <DiscoverLogo className="h-8 w-auto" active={cardType === 'discover'} />
                </div>
              </div>
              
              {/* Security note */}
              <p className="text-xs text-slate-500 mb-2 flex items-center">
                <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                </svg>
                Secure payment - Your payment information is encrypted
              </p>
              
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? (
                  <span className="flex items-center justify-center">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing Payment...
                  </span>
                ) : (
                  <>Pay ${planPrice}/mo</>
                )}
              </Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}