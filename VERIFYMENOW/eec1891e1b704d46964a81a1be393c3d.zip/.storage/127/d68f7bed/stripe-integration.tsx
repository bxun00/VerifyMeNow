import React from "react";
import { toast } from "sonner";

// Mock Stripe functionality since we don't have real API keys yet
export const mockStripePayment = async (paymentDetails: {
  cardNumber: string;
  expiry: string;
  cvc: string;
  name: string;
  planName: string;
  planPrice: string;
}) => {
  // This simulates a payment processing delay
  await new Promise((resolve) => setTimeout(resolve, 2000));
  
  // Validate credit card number format (simple Luhn algorithm check)
  const isValidCardNumber = validateCardNumber(paymentDetails.cardNumber);
  
  if (!isValidCardNumber) {
    throw new Error("Invalid card number");
  }
  
  // Validate expiry date (MM/YY format and not expired)
  const isValidExpiry = validateExpiryDate(paymentDetails.expiry);
  
  if (!isValidExpiry) {
    throw new Error("Card expired or invalid date format");
  }
  
  // Simple CVC validation (3-4 digits)
  if (!/^\d{3,4}$/.test(paymentDetails.cvc.replace(/\s/g, ''))) {
    throw new Error("Invalid CVC code");
  }
  
  // Simulate a successful payment
  return {
    success: true,
    transactionId: `tr_${Math.random().toString(36).substring(2, 10)}`,
    date: new Date().toISOString(),
    last4: paymentDetails.cardNumber.slice(-4),
    cardType: detectCardType(paymentDetails.cardNumber),
  };
};

// Helper function to validate credit card number using Luhn algorithm
const validateCardNumber = (cardNumber: string): boolean => {
  const digits = cardNumber.replace(/\D/g, '');
  
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Simple Luhn algorithm implementation
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i));
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
};

// Helper function to validate expiry date
const validateExpiryDate = (expiry: string): boolean => {
  // Check format MM/YY
  if (!/^\d{1,2}\/\d{2}$/.test(expiry)) {
    return false;
  }
  
  const [monthStr, yearStr] = expiry.split('/');
  const month = parseInt(monthStr, 10);
  const year = parseInt(`20${yearStr}`, 10);
  
  // Check if month is valid
  if (month < 1 || month > 12) {
    return false;
  }
  
  const currentDate = new Date();
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth() + 1;
  
  // Check if the card is not expired
  if (year < currentYear || (year === currentYear && month < currentMonth)) {
    return false;
  }
  
  return true;
};

// Helper function to detect card type based on card number
export const detectCardType = (cardNumber: string): string => {
  const cleanNumber = cardNumber.replace(/\D/g, '');
  
  // Visa cards start with 4
  if (/^4/.test(cleanNumber)) {
    return 'visa';
  }
  
  // Mastercard starts with 51-55 or 2221-2720
  if (/^5[1-5]/.test(cleanNumber) || /^2[2-7][0-9]{2}/.test(cleanNumber)) {
    return 'mastercard';
  }
  
  // American Express starts with 34 or 37
  if (/^3[47]/.test(cleanNumber)) {
    return 'amex';
  }
  
  // Discover starts with 6011, 622126-622925, 644-649, 65
  if (/^(6011|65|64[4-9]|622(12[6-9]|1[3-9]|[2-8]|9[01]|92[0-5]))/.test(cleanNumber)) {
    return 'discover';
  }
  
  return 'unknown';
};

// Function to format card number with spaces for better readability
export const formatCardNumber = (value: string): string => {
  const cleanValue = value.replace(/\D/g, '');
  const cardType = detectCardType(cleanValue);
  
  if (cardType === 'amex') {
    // Format: XXXX XXXXXX XXXXX
    return cleanValue
      .replace(/(\d{4})/, '$1 ')
      .replace(/(\d{4}) (\d{6})/, '$1 $2 ')
      .substring(0, 17);
  } else {
    // Format: XXXX XXXX XXXX XXXX
    return cleanValue
      .replace(/(\d{4})/, '$1 ')
      .replace(/(\d{4}) (\d{4})/, '$1 $2 ')
      .replace(/(\d{4}) (\d{4}) (\d{4})/, '$1 $2 $3 ')
      .substring(0, 19);
  }
};

// This function helps show secure card details (only last 4 digits)
export const maskCardNumber = (cardNumber: string): string => {
  const last4 = cardNumber.slice(-4);
  return `•••• •••• •••• ${last4}`;
};