import { HOW_IT_WORKS_STEPS } from "@/lib/constants";
import { Icons } from "@/components/icons";

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-20 bg-gradient-to-b from-blue-50 to-white">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl text-blue-900">
            How It Works
          </h2>
          <p className="mt-4 text-lg text-slate-600 max-w-2xl mx-auto">
            Our verification process is simple, fast, and reliable
          </p>
        </div>
        
        <div className="relative">
          {/* Connecting Line */}
          <div className="hidden lg:block absolute left-1/2 top-12 bottom-12 w-0.5 bg-blue-200 -translate-x-1/2" />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {HOW_IT_WORKS_STEPS.map((step, index) => {
              const Icon = Icons[step.icon as keyof typeof Icons];
              return (
                <div 
                  key={index} 
                  className="relative flex flex-col items-center text-center"
                >
                  <div className="relative z-10 bg-white rounded-full border-4 border-blue-100 w-20 h-20 flex items-center justify-center mb-6 shadow-md">
                    <Icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <div className="absolute top-9 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white text-sm font-bold w-6 h-6 rounded-full flex items-center justify-center">
                    {step.step}
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">{step.title}</h3>
                  <p className="text-slate-600">{step.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}