import { PRICING_PLANS } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { CheckIcon } from "@radix-ui/react-icons";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";

export function PricingSection() {
  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl text-blue-900">
            Simple, Transparent Pricing
          </h2>
          <p className="mt-4 text-lg text-slate-600 max-w-2xl mx-auto">
            Choose the plan that works best for you and your team
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {PRICING_PLANS.map((plan, index) => (
            <Card 
              key={index} 
              className={`border-slate-200 relative overflow-hidden transition-all duration-200 hover:shadow-lg ${
                plan.popular ? "border-blue-400 shadow-md" : ""
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 right-0">
                  <Badge variant="default" className="rounded-tl-none rounded-br-none bg-blue-600">
                    Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="pb-0">
                <h3 className="text-lg font-semibold text-slate-900">{plan.name}</h3>
              </CardHeader>
              
              <CardContent className="pt-4">
                <div className="flex items-baseline mb-4">
                  <span className="text-3xl font-bold text-slate-900">${plan.price}</span>
                  <span className="text-sm font-medium text-slate-500 ml-1">/mo</span>
                </div>
                
                <p className="text-sm text-slate-600 mb-6">{plan.description}</p>
                
                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <CheckIcon className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span className="text-sm text-slate-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              
              <CardFooter className="pt-4">
                <Button 
                  className={`w-full ${plan.popular ? "" : "bg-blue-600 hover:bg-blue-700"}`}
                  variant={plan.popular ? "default" : "outline"}
                >
                  {plan.cta}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}