import { TRUST_LOGOS } from "@/lib/constants";

export function TrustLogosSection() {
  return (
    <section className="py-12 bg-slate-50 border-y border-slate-200">
      <div className="container px-4 md:px-6">
        <p className="text-center text-sm font-medium text-slate-500 mb-6">
          TRUSTED BY COMPANIES WORLDWIDE
        </p>
        
        <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-6">
          {TRUST_LOGOS.map((logo, index) => (
            <div key={index} className="text-lg sm:text-xl font-semibold text-slate-400">
              {logo}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}