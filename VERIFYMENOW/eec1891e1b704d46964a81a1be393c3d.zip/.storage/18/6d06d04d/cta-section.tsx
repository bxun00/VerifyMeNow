import { Button } from "@/components/ui/button";

export function CTASection() {
  return (
    <section id="contact" className="py-20 bg-blue-600">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="lg:max-w-2xl">
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl md:text-5xl">
              Ready to simplify your verification process?
            </h2>
            <p className="mt-4 text-lg text-blue-100 max-w-2xl">
              Join thousands of businesses that trust VerifyMeNow for their identity verification needs. 
              Get started today with a free trial.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" variant="secondary" className="text-blue-600 bg-white hover:bg-blue-50 shadow-lg">
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-blue-700">
              Schedule Demo
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}