import { Button } from "@/components/ui/button";
import { Layout } from "@/components/layout/layout";
import { Icons } from "@/components/icons";

export default function NotFound() {
  return (
    <Layout>
      <div className="flex flex-col items-center justify-center py-32 px-4 text-center">
        <Icons.Logo className="h-12 w-12 text-blue-600 mb-6" />
        <h1 className="text-4xl font-bold tracking-tight text-slate-900 mb-2">404</h1>
        <h2 className="text-2xl font-semibold mb-4">Page Not Found</h2>
        <p className="text-slate-600 mb-8 max-w-md">
          The page you are looking for doesn't exist or has been moved.
          Let's get you back to the home page.
        </p>
        <Button asChild size="lg">
          <a href="/">Go Back Home</a>
        </Button>
      </div>
    </Layout>
  );
}