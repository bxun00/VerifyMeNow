import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQ_ITEMS = [
  {
    question: "How fast are the verification results?",
    answer: "Most identity verifications are completed within seconds. Document authentication typically takes less than a minute, and comprehensive background checks are completed within 24-48 hours depending on the scope."
  },
  {
    question: "Is VerifyMeNow compliant with international regulations?",
    answer: "Yes, our platform is compliant with global regulations including GDPR, KYC, AML, and region-specific requirements. We regularly update our compliance measures to adapt to changing regulations."
  },
  {
    question: "How secure is the verification process?",
    answer: "We use bank-level encryption and security protocols to protect all data. Our platform is SOC 2 Type II certified and undergoes regular security audits. We never store sensitive information unless explicitly required by our clients."
  },
  {
    question: "Can I integrate VerifyMeNow with my existing systems?",
    answer: "Absolutely. We provide comprehensive API documentation and SDKs for major programming languages. Our integration specialists can assist with custom implementations for enterprise clients."
  },
  {
    question: "What types of documents can be verified?",
    answer: "We can verify government-issued IDs, passports, driver's licenses, residence permits, utility bills, bank statements, educational certificates, and many other official documents from over 190 countries."
  },
];

export function FAQSection() {
  return (
    <section id="faq" className="py-20 bg-slate-50 border-t border-slate-200">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl text-blue-900">
            Frequently Asked Questions
          </h2>
          <p className="mt-4 text-lg text-slate-600 max-w-2xl mx-auto">
            Find answers to common questions about our verification services
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {FAQ_ITEMS.map((item, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left font-medium text-lg text-slate-900">
                  {item.question}
                </AccordionTrigger>
                <AccordionContent className="text-slate-600">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}