import { useState } from "react";
import { PRICING_PLANS } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { CheckIcon } from "@radix-ui/react-icons";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { PaymentModal } from "@/components/payment/payment-modal";

export function PricingSection() {
  const [selectedPlan, setSelectedPlan] = useState<{
    name: string;
    price: string;
  } | null>(null);

  const handleSubscribe = (planName: string, planPrice: string) => {
    setSelectedPlan({ name: planName, price: planPrice });
  };

  const handleCloseModal = () => {
    setSelectedPlan(null);
  };

  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl text-blue-900">
            Simple, Transparent Pricing
          </h2>
          <p className="mt-4 text-lg text-slate-600 max-w-2xl mx-auto">
            Choose the plan that works best for you and your team
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PRICING_PLANS.map((plan, index) => (
            <Card 
              key={index} 
              className={`border-slate-200 relative overflow-hidden transition-all duration-200 hover:shadow-lg ${
                plan.popular ? "border-blue-400 shadow-md" : ""
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 right-0">
                  <Badge variant="default" className="rounded-tl-none rounded-br-none bg-blue-600">
                    Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="pb-0">
                <h3 className="text-lg font-semibold text-slate-900">{plan.name}</h3>
              </CardHeader>
              
              <CardContent className="pt-4">
                <div className="flex items-baseline mb-4">
                  <span className="text-3xl font-bold text-slate-900">${plan.price}</span>
                  {plan.price !== "Custom" && <span className="text-sm font-medium text-slate-500 ml-1">/mo</span>}
                </div>
                
                <p className="text-sm text-slate-600 mb-6">{plan.description}</p>
                
                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <CheckIcon className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span className="text-sm text-slate-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              
              <CardFooter className="pt-4">
                <Button 
                  className={`w-full ${plan.popular ? "" : "bg-blue-600 hover:bg-blue-700"}`}
                  variant={plan.popular ? "default" : "outline"}
                  onClick={() => handleSubscribe(plan.name, plan.price)}
                >
                  {plan.cta}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-10 text-center">
          <p className="text-sm text-slate-500 flex items-center justify-center gap-2">
            Secure payments with
            <span className="flex items-center gap-2">
              <svg className="h-6" viewBox="0 0 36 24" fill="none">
                <rect width="36" height="24" rx="4" fill="#FFFFFF" stroke="#E6E6E6" />
                <path d="M10 15.98H26V16C26 19.31 23.31 22 20 22H16C12.69 22 10 19.31 10 16V15.98Z" fill="#EB001B" />
                <path d="M26 8V8.02H10V8C10 4.69 12.69 2 16 2H20C23.31 2 26 4.69 26 8Z" fill="#0099DF" />
                <rect x="10" y="8.02002" width="16" height="7.96" fill="#FFFFFF" />
              </svg>
              <svg className="h-6" viewBox="0 0 36 24" fill="none">
                <rect x="0.5" y="0.5" width="35" height="23" rx="3.5" fill="white" stroke="#D9D9D9" />
                <path fillRule="evenodd" clipRule="evenodd" d="M6.5 15.55C9.74412 15.55 12.37 13.0021 12.37 9.77499C12.37 6.54785 9.74412 4 6.5 4C3.25588 4 0.63 6.54785 0.63 9.77499C0.63 13.0021 3.25588 15.55 6.5 15.55Z" fill="#EB001B" />
                <path fillRule="evenodd" clipRule="evenodd" d="M29.5 15.55C32.7441 15.55 35.37 13.0021 35.37 9.77499C35.37 6.54785 32.7441 4 29.5 4C26.2559 4 23.63 6.54785 23.63 9.77499C23.63 13.0021 26.2559 15.55 29.5 15.55Z" fill="#0099DF" />
                <path fillRule="evenodd" clipRule="evenodd" d="M18 4.1084C19.6133 5.36571 20.6869 7.20164 20.6869 9.2637C20.6869 11.3258 19.6133 13.1617 18 14.419C16.3867 13.1617 15.3131 11.3258 15.3131 9.2637C15.3131 7.20164 16.3867 5.36571 18 4.1084Z" fill="#6C6BBD" />
              </svg>
              <svg className="h-6" viewBox="0 0 36 24" fill="none">
                <rect x="0.5" y="0.5" width="35" height="23" rx="3.5" fill="white" stroke="#D9D9D9" />
                <path d="M14.2421 16.7331H12.7848L13.7583 7.26514H15.2156L14.2421 16.7331Z" fill="#00579F" />
                <path d="M21.3726 7.43896C20.9755 7.26688 20.3593 7.0948 19.6211 7.0948C17.8814 7.0948 16.6389 8.0367 16.632 9.42013C16.6253 10.4567 17.5375 11.0304 18.2302 11.3745C18.9367 11.725 19.1919 11.9457 19.1919 12.2467C19.1867 12.7018 18.6228 12.9159 18.0928 12.9159C17.3591 12.9159 16.9691 12.7931 16.3825 12.5255L16.1409 12.4076L15.8799 13.71C16.35 13.9369 17.2132 14.1368 18.1048 14.1437C19.9566 14.1437 21.1784 13.2155 21.1922 11.7213C21.1991 10.9052 20.7268 10.2772 19.6625 9.7696C18.9978 9.43183 18.5871 9.20419 18.5871 8.86643C18.5939 8.56543 18.9159 8.26442 19.6142 8.26442C20.1784 8.25783 20.6183 8.41345 20.9547 8.56873L21.1267 8.65343L21.3726 7.43896Z" fill="#00579F" />
                <path d="M23.8217 13.2971C24.0193 12.7962 24.6748 11.1023 24.6748 11.1023C24.6679 11.1155 24.8172 10.7185 24.9042 10.4699L25.0326 11.0304C25.0326 11.0304 25.4226 12.8437 25.5168 13.2971H23.8217ZM26.3213 7.26514H25.1477C24.713 7.26514 24.3921 7.38741 24.1945 7.82478L20.9824 16.7332H22.8411C22.8411 16.7332 23.2036 15.6291 23.2793 15.4097C23.5044 15.4097 25.4296 15.4097 25.7126 15.4097C25.7746 15.6819 25.9653 16.7332 25.9653 16.7332H27.6329L26.3213 7.26514Z" fill="#00579F" />
                <path d="M10.4472 7.26514L8.71991 13.6883L8.52401 12.7271C8.17036 11.1947 6.90392 9.53716 5.49805 8.70487L7.09176 16.7265H9.00057L11.9196 7.26514H10.4472Z" fill="#00579F" />
                <path d="M7.06879 8.07419H4.2666C4.22109 8.08717 4.17578 8.10066 4.13066 8.11463C3.1847 8.22363 2.44984 8.67398 2.44984 8.67398L2.45312 8.72308L5.3849 16.7331H7.29718L8.45604 9.32572C8.45604 9.32572 8.62323 8.43602 8.64559 8.28039C8.13217 8.13775 7.61524 8.05047 7.09556 8.01939C7.08631 8.03566 7.07671 8.05216 7.06879 8.07419Z" fill="#FAA61A" />
              </svg>
              <svg className="h-6" viewBox="0 0 60 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="60" height="24" rx="4" fill="#FFFFFF" />
                <path d="M47.4817 7.21681C45.8738 7.21681 44.5771 8.51343 44.5771 10.1213C44.5771 11.7293 45.8738 13.0259 47.4817 13.0259C49.0896 13.0259 50.3862 11.7293 50.3862 10.1213C50.3862 8.51343 49.0896 7.21681 47.4817 7.21681Z" fill="#179BD7" />
                <path d="M24.0346 7.75342H20.7454C20.4401 7.75342 20.1826 7.96508 20.1245 8.26459L18.3391 19.2082C18.2944 19.4431 18.4745 19.6584 18.7132 19.6584H20.2921C20.5977 19.6584 20.8555 19.4465 20.9133 19.147L21.3598 16.5368C21.4173 16.2373 21.6751 16.0257 21.9804 16.0257H23.0352C25.649 16.0257 27.2115 14.721 27.6133 12.2138C27.7948 11.1197 27.5897 10.2497 27.0243 9.65156C26.4005 8.98645 25.3484 8.75342 24.0346 8.75342H24.0346ZM24.471 12.3263C24.2488 13.6464 23.2139 13.6464 22.2071 13.6464H21.7036L22.1413 11.1324C22.1718 10.9642 22.3193 10.841 22.4906 10.841H22.7196C23.4148 10.841 24.0731 10.841 24.4112 11.2048C24.6115 11.4192 24.6809 11.7747 24.471 12.3263L24.471 12.3263Z" fill="#253B80" />
                <path d="M35.8387 12.2981H34.2569C34.0856 12.2981 33.9381 12.4213 33.9076 12.5894L33.8254 13.084L33.6905 12.8837C33.2744 12.2428 32.3493 12.051 31.4241 12.051C29.3268 12.051 27.5414 13.6297 27.1661 15.7973C26.9746 16.8782 27.1966 17.9127 27.7853 18.6442C28.3262 19.3165 29.1356 19.5988 30.1099 19.5988C31.8281 19.5988 32.7612 18.535 32.7612 18.535L32.6787 19.0288C32.634 19.2638 32.8141 19.4791 33.0526 19.4791H34.4771C34.7827 19.4791 35.0402 19.2675 35.098 18.968L36.2128 12.7483C36.2575 12.5134 36.0774 12.2981 35.8387 12.2981L35.8387 12.2981ZM33.2933 15.8438C33.0971 16.9001 32.2724 17.6124 31.1893 17.6124C30.6479 17.6124 30.2167 17.441 29.9471 17.1155C29.6801 16.7928 29.5791 16.3129 29.6746 15.7845C29.8547 14.7391 30.6964 14.0374 31.7568 14.0374C32.2842 14.0374 32.7105 14.2113 32.9863 14.5376C33.2638 14.8667 33.3749 15.3488 33.2933 15.8438L33.2933 15.8438Z" fill="#253B80" />
                <path d="M42.1355 12.2981H40.5466C40.3535 12.2981 40.1754 12.3988 40.0805 12.5692L37.6428 16.2029L36.6226 12.6895C36.5491 12.4547 36.3341 12.2981 36.0882 12.2981H34.5306C34.2603 12.2981 34.0802 12.5662 34.1549 12.8253L35.951 18.7376L34.204 21.2939C34.0114 21.5697 34.192 21.9421 34.5242 21.9421H36.1102C36.3016 21.9421 36.4783 21.8436 36.5739 21.6755L42.5485 12.9463C42.7401 12.6704 42.5595 12.2981 42.1355 12.2981L42.1355 12.2981Z" fill="#253B80" />
                <path d="M51.3238 7.75342H48.0346C47.7293 7.75342 47.4718 7.96508 47.4136 8.26459L45.6283 19.2082C45.5835 19.4431 45.7636 19.6584 46.0023 19.6584H47.6859C47.9211 19.6584 48.1234 19.4915 48.161 19.2584L48.6257 16.5368C48.6832 16.2373 48.941 16.0257 49.2464 16.0257H50.3011C52.9149 16.0257 54.4774 14.721 54.8792 12.2138C55.0608 11.1197 54.8557 10.2497 54.2902 9.65156C53.6664 8.98645 52.6143 8.75342 51.3238 8.75342ZM51.7602 12.3263C51.538 13.6464 50.5031 13.6464 49.4963 13.6464H48.9928L49.4305 11.1324C49.461 10.9642 49.6085 10.841 49.7798 10.841H50.0088C50.704 10.841 51.3623 10.841 51.7004 11.2048C51.9007 11.4192 51.9701 11.7747 51.7602 12.3263Z" fill="#179BD7" />
                <path d="M63.1279 12.2981H61.5461C61.3748 12.2981 61.2273 12.4213 61.1968 12.5894L61.1146 13.084L60.9797 12.8837C60.5636 12.2428 59.6385 12.051 58.7133 12.051C56.616 12.051 54.8306 13.6297 54.4553 15.7973C54.2638 16.8782 54.4858 17.9127 55.0745 18.6442C55.6153 19.3165 56.4248 19.5988 57.3991 19.5988C59.1173 19.5988 60.0504 18.535 60.0504 18.535L59.9679 19.0288C59.9232 19.2638 60.1033 19.4791 60.3418 19.4791H61.7663C62.0719 19.4791 62.3294 19.2675 62.3872 18.968L63.502 12.7483C63.5467 12.5134 63.3666 12.2981 63.1279 12.2981ZM60.5825 15.8438C60.3863 16.9001 59.5616 17.6124 58.4785 17.6124C57.9371 17.6124 57.5059 17.441 57.2363 17.1155C56.9693 16.7928 56.8683 16.3129 56.9638 15.7845C57.1439 14.7391 57.9856 14.0374 59.046 14.0374C59.5734 14.0374 59.9997 14.2113 60.2755 14.5376C60.553 14.8667 60.6641 15.3488 60.5825 15.8438Z" fill="#179BD7" />
              </svg>
            </span>
          </p>
        </div>
      </div>

      {selectedPlan && (
        <PaymentModal
          isOpen={!!selectedPlan}
          onClose={handleCloseModal}
          planName={selectedPlan.name}
          planPrice={selectedPlan.price}
        />
      )}
    </section>
  );
}