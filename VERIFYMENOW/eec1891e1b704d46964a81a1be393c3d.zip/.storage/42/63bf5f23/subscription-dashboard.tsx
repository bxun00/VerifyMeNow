import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { PaymentModal } from "@/components/payment/payment-modal";

// Mock data
const mockSubscription = {
  plan: "Business",
  status: "active",
  nextBillingDate: "November 15, 2025",
  price: "49.99",
  startDate: "October 15, 2025",
  paymentMethod: "Visa ending in 4242",
};

const mockUsage = {
  verifications: {
    used: 358,
    limit: 500,
    percentage: 71.6,
  },
  apiCalls: {
    used: 8742,
    limit: 10000,
    percentage: 87.4,
  },
};

const mockInvoices = [
  {
    id: "INV-2025-10-15",
    date: "October 15, 2025",
    amount: "$49.99",
    status: "Paid",
  },
  {
    id: "INV-2025-09-15",
    date: "September 15, 2025",
    amount: "$49.99",
    status: "Paid",
  },
  {
    id: "INV-2025-08-15",
    date: "August 15, 2025",
    amount: "$49.99",
    status: "Paid",
  },
];

export function SubscriptionDashboard() {
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [selectedUpgradePlan, setSelectedUpgradePlan] = useState<{
    name: string;
    price: string;
  } | null>(null);

  const handleUpgrade = (planName: string, planPrice: string) => {
    setSelectedUpgradePlan({ name: planName, price: planPrice });
    setIsPaymentModalOpen(true);
  };

  const handleCancelSubscription = () => {
    const confirmCancel = window.confirm(
      "Are you sure you want to cancel your subscription? Your service will continue until the end of the current billing period."
    );

    if (confirmCancel) {
      toast.success("Your subscription has been canceled", {
        description: "Service will continue until November 15, 2025",
      });
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-blue-900 mb-8">Account Dashboard</h1>
      
      <Tabs defaultValue="subscription" className="w-full">
        <TabsList className="mb-8">
          <TabsTrigger value="subscription">Subscription</TabsTrigger>
          <TabsTrigger value="usage">Usage</TabsTrigger>
          <TabsTrigger value="invoices">Invoices</TabsTrigger>
        </TabsList>
        
        <TabsContent value="subscription">
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Current Plan
                  <Badge variant={mockSubscription.status === "active" ? "default" : "outline"} className="capitalize">
                    {mockSubscription.status}
                  </Badge>
                </CardTitle>
                <CardDescription>Manage your subscription plan</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold text-blue-800">{mockSubscription.plan} Plan</h3>
                    <p className="text-lg text-blue-600">${mockSubscription.price}/month</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Next billing date</span>
                      <span className="font-medium">{mockSubscription.nextBillingDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Start date</span>
                      <span className="font-medium">{mockSubscription.startDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Payment method</span>
                      <span className="font-medium">{mockSubscription.paymentMethod}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col sm:flex-row gap-4">
                <Button variant="outline" className="w-full sm:w-auto" onClick={() => handleUpgrade("Premium", "99.99")}>
                  Upgrade Plan
                </Button>
                <Button 
                  variant="destructive" 
                  className="w-full sm:w-auto"
                  onClick={handleCancelSubscription}
                >
                  Cancel Subscription
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
                <CardDescription>Update your payment information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 p-4 border rounded-lg mb-4">
                  <div className="h-8 w-12 bg-gradient-to-r from-blue-600 to-blue-800 rounded-md flex items-center justify-center text-white font-bold text-xs">
                    VISA
                  </div>
                  <div>
                    <p className="font-medium">Visa ending in 4242</p>
                    <p className="text-sm text-gray-500">Expires 09/27</p>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">Update Payment Method</Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="usage">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Identity Verifications</CardTitle>
                <CardDescription>
                  {mockUsage.verifications.used} of {mockUsage.verifications.limit} used this billing cycle
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">
                      {mockUsage.verifications.percentage}% used
                    </span>
                    <span className="text-sm text-gray-500">
                      {mockUsage.verifications.limit - mockUsage.verifications.used} remaining
                    </span>
                  </div>
                  <Progress value={mockUsage.verifications.percentage} className="h-2" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>API Calls</CardTitle>
                <CardDescription>
                  {mockUsage.apiCalls.used.toLocaleString()} of {mockUsage.apiCalls.limit.toLocaleString()} used this billing cycle
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">
                      {mockUsage.apiCalls.percentage}% used
                    </span>
                    <span className="text-sm text-gray-500">
                      {(mockUsage.apiCalls.limit - mockUsage.apiCalls.used).toLocaleString()} remaining
                    </span>
                  </div>
                  <Progress value={mockUsage.apiCalls.percentage} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="invoices">
          <Card>
            <CardHeader>
              <CardTitle>Billing History</CardTitle>
              <CardDescription>View your past invoices and payment history</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs uppercase bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3">Invoice ID</th>
                      <th scope="col" className="px-6 py-3">Date</th>
                      <th scope="col" className="px-6 py-3">Amount</th>
                      <th scope="col" className="px-6 py-3">Status</th>
                      <th scope="col" className="px-6 py-3">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockInvoices.map((invoice) => (
                      <tr key={invoice.id} className="bg-white border-b">
                        <td className="px-6 py-4 font-medium text-gray-900">{invoice.id}</td>
                        <td className="px-6 py-4">{invoice.date}</td>
                        <td className="px-6 py-4">{invoice.amount}</td>
                        <td className="px-6 py-4">
                          <Badge variant={invoice.status === "Paid" ? "success" : "destructive"} className="bg-green-100 text-green-800 border-green-200">
                            {invoice.status}
                          </Badge>
                        </td>
                        <td className="px-6 py-4">
                          <Button variant="ghost" size="sm">
                            Download
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {selectedUpgradePlan && isPaymentModalOpen && (
        <PaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          planName={selectedUpgradePlan.name}
          planPrice={selectedUpgradePlan.price}
        />
      )}
    </div>
  );
}