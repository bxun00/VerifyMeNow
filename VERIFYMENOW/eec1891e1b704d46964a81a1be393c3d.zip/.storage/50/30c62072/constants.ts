// Navigation links
export const NAV_LINKS = [
  {
    title: "Features",
    href: "#features",
  },
  {
    title: "How It Works",
    href: "#how-it-works",
  },
  {
    title: "Pricing",
    href: "#pricing",
  },
  {
    title: "Testimonials",
    href: "#testimonials",
  },
  {
    title: "FAQ",
    href: "#faq",
  },
  {
    title: "Contact",
    href: "#contact",
  },
];

// Features list
export const FEATURES = [
  {
    title: "Identity Verification",
    description:
      "Quickly verify identities with our advanced AI algorithms that check against global databases in real-time.",
    icon: "IdCard",
  },
  {
    title: "Document Authentication",
    description:
      "Authenticate official documents including IDs, passports, and certificates with our state-of-the-art forgery detection.",
    icon: "FileCheck",
  },
  {
    title: "Biometric Matching",
    description:
      "Match selfies to ID photos instantly with 99.9% accuracy using facial recognition technology.",
    icon: "Fingerprint",
  },
  {
    title: "Background Checks",
    description:
      "Run comprehensive background checks including criminal records, credit history, and employment verification.",
    icon: "Shield",
  },
  {
    title: "API Integration",
    description:
      "Seamlessly integrate our verification services into your existing systems with our robust API.",
    icon: "Code",
  },
  {
    title: "Compliance Automation",
    description:
      "Stay compliant with global regulations including KYC, AML, and GDPR with automatic updates.",
    icon: "CheckCircle",
  },
];

// How it works steps
export const HOW_IT_WORKS_STEPS = [
  {
    title: "Sign Up",
    description: "Create your account and choose a verification plan that suits your needs.",
    icon: "UserPlus",
  },
  {
    title: "Connect Your Systems",
    description: "Integrate our API with your existing systems or use our web portal.",
    icon: "Link",
  },
  {
    title: "Submit Verification Request",
    description: "Upload documents or provide information needed for verification.",
    icon: "Upload",
  },
  {
    title: "Get Verified Results",
    description: "Receive detailed verification results in seconds, not days.",
    icon: "CheckSquare",
  },
];

// Pricing plans
export const PRICING_PLANS = [
  {
    name: "Starter",
    price: "49",
    description: "Perfect for small businesses just getting started with identity verification.",
    features: [
      "500 verifications per month",
      "Basic ID verification",
      "Document authentication",
      "Email support",
      "API access",
    ],
    cta: "Get Started",
    popular: false,
  },
  {
    name: "Business",
    price: "149",
    description: "Ideal for growing businesses with moderate verification needs.",
    features: [
      "2,500 verifications per month",
      "Advanced ID verification",
      "Document authentication",
      "Biometric matching",
      "Background checks",
      "Priority support",
      "Full API access",
    ],
    cta: "Start Free Trial",
    popular: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "For large organizations with high-volume verification requirements.",
    features: [
      "Unlimited verifications",
      "All verification methods",
      "Custom integration",
      "Dedicated account manager",
      "SLA guarantees",
      "Enterprise-grade security",
      "Compliance monitoring",
    ],
    cta: "Contact Sales",
    popular: false,
  },
];

// Trust logos
export const TRUST_LOGOS = [
  "Acme Inc.",
  "TechCorp",
  "GlobalFin",
  "SecureID",
  "FastVerify",
  "TrustBank",
];

// Social links
export const SOCIAL_LINKS = [
  {
    name: "Twitter",
    href: "https://twitter.com/verifyme",
    icon: "Twitter",
  },
  {
    name: "LinkedIn",
    href: "https://linkedin.com/company/verifyme",
    icon: "Linkedin",
  },
  {
    name: "Facebook",
    href: "https://facebook.com/verifyme",
    icon: "Facebook",
  },
  {
    name: "Instagram",
    href: "https://instagram.com/verifyme",
    icon: "Instagram",
  },
];

// Footer links
export const FOOTER_LINKS = [
  {
    title: "Product",
    links: [
      { title: "Features", href: "#features" },
      { title: "Integrations", href: "#" },
      { title: "API", href: "#" },
      { title: "Documentation", href: "#" },
    ],
  },
  {
    title: "Company",
    links: [
      { title: "About", href: "#" },
      { title: "Customers", href: "#" },
      { title: "Careers", href: "#" },
      { title: "Press", href: "#" },
    ],
  },
  {
    title: "Resources",
    links: [
      { title: "Blog", href: "#" },
      { title: "Help Center", href: "#" },
      { title: "Community", href: "#" },
      { title: "Webinars", href: "#" },
    ],
  },
  {
    title: "Legal",
    links: [
      { title: "Privacy", href: "#" },
      { title: "Terms", href: "#" },
      { title: "Security", href: "#" },
      { title: "Compliance", href: "#" },
    ],
  },
];