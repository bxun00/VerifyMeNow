import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { Icons } from "../icons";
import { mockStripePayment, formatCardNumber, detectCardType } from "./stripe-integration";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  planName: string;
  planPrice: string;
}

export function PaymentModal({
  isOpen,
  onClose,
  planName,
  planPrice,
}: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState("credit-card");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvc, setCardCvc] = useState("");
  const [cardName, setCardName] = useState("");
  const [cardType, setCardType] = useState("");
  const [error, setError] = useState("");

  // Format card number as it's entered
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = formatCardNumber(e.target.value);
    setCardNumber(value);
    const type = detectCardType(value);
    setCardType(type);
  };

  // Format expiry date as it's entered
  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '');
    if (value.length <= 2) {
      setCardExpiry(value);
    } else {
      setCardExpiry(`${value.slice(0, 2)}/${value.slice(2, 4)}`);
    }
  };

  // Reset form when closing
  useEffect(() => {
    if (!isOpen) {
      setCardNumber("");
      setCardExpiry("");
      setCardCvc("");
      setCardName("");
      setError("");
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsSubmitting(true);

    try {
      if (paymentMethod === "credit-card") {
        const response = await mockStripePayment({
          cardNumber,
          expiry: cardExpiry,
          cvc: cardCvc,
          name: cardName,
          planName,
          planPrice,
        });

        // Create success message with card info
        const cardBrand = response.cardType === 'visa' ? 'Visa' : 
                         response.cardType === 'mastercard' ? 'Mastercard' : 
                         response.cardType === 'amex' ? 'American Express' : 'Card';

        toast.success("Payment received! Thank you for your subscription.", {
          description: `Your ${planName} plan is now active. Charged to ${cardBrand} ending in ${response.last4}.`,
          duration: 5000,
        });
      } else {
        // PayPal flow would redirect in real implementation
        toast.success("PayPal payment completed successfully!", {
          description: `Your ${planName} plan is now active.`,
          duration: 5000,
        });
      }

      onClose();
    } catch (err: any) {
      setError(err.message || "Payment failed. Please try again.");
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Subscribe to {planName}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Plan</Label>
              <span className="font-medium">{planName}</span>
            </div>
            <div className="flex justify-between">
              <Label>Price</Label>
              <span className="font-medium">${planPrice}/mo</span>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Payment Method</Label>
            <RadioGroup
              defaultValue="credit-card"
              value={paymentMethod}
              onValueChange={setPaymentMethod}
              className="grid grid-cols-2 gap-4"
            >
              <div className={`flex items-center space-x-2 border rounded-md p-3 cursor-pointer hover:bg-slate-50 ${paymentMethod === 'credit-card' ? 'border-blue-600 bg-blue-50' : ''}`}>
                <RadioGroupItem value="credit-card" id="credit-card" />
                <Label htmlFor="credit-card" className="flex items-center cursor-pointer">
                  <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect width="20" height="14" x="2" y="5" rx="2" stroke="currentColor" strokeWidth="2" />
                    <path d="M2 10H22" stroke="currentColor" strokeWidth="2" />
                  </svg>
                  Credit/Debit Card
                </Label>
              </div>
              <div className={`flex items-center space-x-2 border rounded-md p-3 cursor-pointer hover:bg-slate-50 ${paymentMethod === 'paypal' ? 'border-blue-600 bg-blue-50' : ''}`}>
                <RadioGroupItem value="paypal" id="paypal" />
                <Label htmlFor="paypal" className="flex items-center cursor-pointer">
                  <svg className="h-5 w-5 mr-2 text-blue-600" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19.0803 6.10872C19.2539 5.31237 19.0803 4.76279 18.6532 4.31532C18.1828 3.77982 17.3285 3.5 16.2639 3.5H11.5745C11.36 3.5 11.1455 3.66684 11.0954 3.86776L9.20359 14.8197C9.20359 15.0206 9.32824 15.1875 9.54269 15.1875H11.8825L11.7078 16.2668C11.6578 16.4677 11.7824 16.6346 11.997 16.6346H14.0136C14.2281 16.6346 14.4427 16.4677 14.4427 16.2668V16.1838L15.2003 11.6077V11.5246C15.2003 11.3238 15.4149 11.1569 15.6294 11.1569H15.9305C17.8278 11.1569 19.3232 10.4274 19.8837 8.28481C20.1848 7.30603 20.0936 6.49148 19.6164 5.96012C19.4853 5.7593 19.3151 5.5986 19.0803 5.53187" stroke="currentColor" strokeWidth="1.5"/>
                    <path d="M18.3066 5.56489C18.2677 5.55212 18.2269 5.53996 18.1848 5.52847C18.1427 5.51699 18.1 5.50599 18.0565 5.49556C17.7668 5.43756 17.4516 5.41066 17.1216 5.41066H13.6265C13.5511 5.41066 13.4789 5.43138 13.4177 5.46783C13.2904 5.54374 13.2005 5.68578 13.1741 5.85784L12.5 10.0736L12.4375 10.4029C12.4854 10.1167 12.7318 9.92268 13.0187 9.92268H14.2524C16.4745 9.92268 18.1759 9.04181 18.8244 6.48724C18.8466 6.39847 18.8658 6.31265 18.8829 6.2295C18.7564 6.0233 18.5905 5.85784 18.3832 5.72775C18.3589 5.67226 18.3328 5.61749 18.3066 5.56489Z" stroke="currentColor" strokeWidth="1.5"/>
                    <path d="M13.1742 5.85767C13.2007 5.68561 13.2905 5.54356 13.4179 5.46775C13.4791 5.4313 13.5513 5.41058 13.6266 5.41058H17.1217C17.4518 5.41058 17.767 5.43748 18.0566 5.49549C18.1001 5.50591 18.1428 5.51691 18.1849 5.52839C18.227 5.53988 18.2679 5.55204 18.3068 5.56482C18.3329 5.61742 18.359 5.67219 18.3834 5.72767C18.5906 5.85767 18.7565 6.02322 18.883 6.22933C18.9755 7.10342 18.8599 7.82436 18.4481 8.34786C17.9174 8.97967 17.0077 9.27945 15.8667 9.27945H14.7855C14.4852 9.27945 14.2351 9.53029 14.185 9.82973L13.6349 13.0704L13.4179 14.1819C13.4179 14.3138 13.5078 14.4458 13.6266 14.4458H15.4484C15.6355 14.4458 15.8057 14.3139 15.8557 14.1322V14.0924L16.3089 11.3198V11.27C16.3089 11.0884 16.4789 10.9563 16.6661 10.9563H16.882C17.8164 10.9563 18.591 10.7249 19.0528 10.2622C19.5646 9.76958 19.7498 9.10694 19.6599 8.34786C19.5784 7.3041 19.0347 6.51435 18.2432 6.06232" stroke="currentColor" strokeWidth="1.5"/>
                  </svg>
                  PayPal
                </Label>
              </div>
            </RadioGroup>
          </div>

          {paymentMethod === "credit-card" && (
            <div className="space-y-4">
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-2 rounded-md text-sm">
                  {error}
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="card-number">Card Number</Label>
                <div className="relative">
                  <Input 
                    id="card-number" 
                    placeholder="1234 5678 9012 3456" 
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    required 
                    className="pr-10"
                    maxLength={19}
                  />
                  {cardType === 'visa' && (
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-blue-600 font-semibold">
                      VISA
                    </span>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input 
                    id="expiry" 
                    placeholder="MM/YY" 
                    value={cardExpiry}
                    onChange={handleExpiryChange}
                    required 
                    maxLength={5}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cvc">CVC</Label>
                  <Input 
                    id="cvc" 
                    placeholder="123" 
                    value={cardCvc}
                    onChange={(e) => setCardCvc(e.target.value.replace(/\D/g, '').substring(0, 4))}
                    required 
                    maxLength={4}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">Name on Card</Label>
                <Input 
                  id="name" 
                  placeholder="John Doe" 
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value)}
                  required 
                />
              </div>
            </div>
          )}

          {paymentMethod === "paypal" && (
            <div className="text-center py-6">
              <p className="text-sm text-slate-600 mb-4">
                You'll be redirected to PayPal to complete your payment
              </p>
              <svg
                className="w-12 h-12 mx-auto text-blue-600"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M19.0803 6.10872C19.2539 5.31237 19.0803 4.76279 18.6532 4.31532C18.1828 3.77982 17.3285 3.5 16.2639 3.5H11.5745C11.36 3.5 11.1455 3.66684 11.0954 3.86776L9.20359 14.8197C9.20359 15.0206 9.32824 15.1875 9.54269 15.1875H11.8825L11.7078 16.2668C11.6578 16.4677 11.7824 16.6346 11.997 16.6346H14.0136C14.2281 16.6346 14.4427 16.4677 14.4427 16.2668V16.1838L15.2003 11.6077V11.5246C15.2003 11.3238 15.4149 11.1569 15.6294 11.1569H15.9305C17.8278 11.1569 19.3232 10.4274 19.8837 8.28481C20.1848 7.30603 20.0936 6.49148 19.6164 5.96012C19.4853 5.7593 19.3151 5.5986 19.0803 5.53187"
                  stroke="currentColor"
                  strokeWidth="2"
                />
                <path
                  d="M18.3066 5.56489C18.2677 5.55212 18.2269 5.53996 18.1848 5.52847C18.1427 5.51699 18.1 5.50599 18.0565 5.49556C17.7668 5.43756 17.4516 5.41066 17.1216 5.41066H13.6265C13.5511 5.41066 13.4789 5.43138 13.4177 5.46783C13.2904 5.54374 13.2005 5.68578 13.1741 5.85784L12.5 10.0736L12.4375 10.4029C12.4854 10.1167 12.7318 9.92268 13.0187 9.92268H14.2524C16.4745 9.92268 18.1759 9.04181 18.8244 6.48724C18.8466 6.39847 18.8658 6.31265 18.8829 6.2295C18.7564 6.0233 18.5905 5.85784 18.3832 5.72775C18.3589 5.67226 18.3328 5.61749 18.3066 5.56489Z"
                  stroke="currentColor"
                  strokeWidth="2"
                />
                <path
                  d="M13.1742 5.85767C13.2007 5.68561 13.2905 5.54356 13.4179 5.46775C13.4791 5.4313 13.5513 5.41058 13.6266 5.41058H17.1217C17.4518 5.41058 17.767 5.43748 18.0566 5.49549C18.1001 5.50591 18.1428 5.51691 18.1849 5.52839C18.227 5.53988 18.2679 5.55204 18.3068 5.56482C18.3329 5.61742 18.359 5.67219 18.3834 5.72767C18.5906 5.85767 18.7565 6.02322 18.883 6.22933C18.9755 7.10342 18.8599 7.82436 18.4481 8.34786C17.9174 8.97967 17.0077 9.27945 15.8667 9.27945H14.7855C14.4852 9.27945 14.2351 9.53029 14.185 9.82973L13.6349 13.0704L13.4179 14.1819C13.4179 14.3138 13.5078 14.4458 13.6266 14.4458H15.4484C15.6355 14.4458 15.8057 14.3139 15.8557 14.1322V14.0924L16.3089 11.3198V11.27C16.3089 11.0884 16.4789 10.9563 16.6661 10.9563H16.882C17.8164 10.9563 18.591 10.7249 19.0528 10.2622C19.5646 9.76958 19.7498 9.10694 19.6599 8.34786C19.5784 7.3041 19.0347 6.51435 18.2432 6.06232"
                  stroke="currentColor"
                  strokeWidth="2"
                />
              </svg>
            </div>
          )}

          <DialogFooter>
            <div className="flex flex-col w-full space-y-2">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-slate-600">Payment Methods:</span>
                <div className="flex space-x-2">
                  <svg className="h-6 w-auto text-slate-400" viewBox="0 0 36 24" fill="none">
                    <rect width="36" height="24" rx="4" fill="#FFFFFF" />
                    <path d="M10 15.98H26V16C26 19.31 23.31 22 20 22H16C12.69 22 10 19.31 10 16V15.98Z" fill="#EB001B" />
                    <path d="M26 8V8.02H10V8C10 4.69 12.69 2 16 2H20C23.31 2 26 4.69 26 8Z" fill="#0099DF" />
                    <rect x="10" y="8.02002" width="16" height="7.96" fill="#FFFFFF" />
                  </svg>
                  <svg className="h-6 w-auto text-slate-400" viewBox="0 0 36 24" fill="none">
                    <rect x="0.5" y="0.5" width="35" height="23" rx="3.5" fill="white" stroke="#D9D9D9" />
                    <path fillRule="evenodd" clipRule="evenodd" d="M6.5 15.55C9.74412 15.55 12.37 13.0021 12.37 9.77499C12.37 6.54785 9.74412 4 6.5 4C3.25588 4 0.63 6.54785 0.63 9.77499C0.63 13.0021 3.25588 15.55 6.5 15.55Z" fill="#EB001B" />
                    <path fillRule="evenodd" clipRule="evenodd" d="M29.5 15.55C32.7441 15.55 35.37 13.0021 35.37 9.77499C35.37 6.54785 32.7441 4 29.5 4C26.2559 4 23.63 6.54785 23.63 9.77499C23.63 13.0021 26.2559 15.55 29.5 15.55Z" fill="#0099DF" />
                    <path fillRule="evenodd" clipRule="evenodd" d="M18 4.1084C19.6133 5.36571 20.6869 7.20164 20.6869 9.2637C20.6869 11.3258 19.6133 13.1617 18 14.419C16.3867 13.1617 15.3131 11.3258 15.3131 9.2637C15.3131 7.20164 16.3867 5.36571 18 4.1084Z" fill="#6C6BBD" />
                  </svg>
                  <svg className="h-6 w-auto text-slate-400" viewBox="0 0 36 24" fill="none">
                    <rect x="0.5" y="0.5" width="35" height="23" rx="3.5" fill="white" stroke="#D9D9D9" />
                    <path d="M14.2421 16.7331H12.7848L13.7583 7.26514H15.2156L14.2421 16.7331Z" fill="#00579F" />
                    <path d="M21.3726 7.43896C20.9755 7.26688 20.3593 7.0948 19.6211 7.0948C17.8814 7.0948 16.6389 8.0367 16.632 9.42013C16.6253 10.4567 17.5375 11.0304 18.2302 11.3745C18.9367 11.725 19.1919 11.9457 19.1919 12.2467C19.1867 12.7018 18.6228 12.9159 18.0928 12.9159C17.3591 12.9159 16.9691 12.7931 16.3825 12.5255L16.1409 12.4076L15.8799 13.71C16.35 13.9369 17.2132 14.1368 18.1048 14.1437C19.9566 14.1437 21.1784 13.2155 21.1922 11.7213C21.1991 10.9052 20.7268 10.2772 19.6625 9.7696C18.9978 9.43183 18.5871 9.20419 18.5871 8.86643C18.5939 8.56543 18.9159 8.26442 19.6142 8.26442C20.1784 8.25783 20.6183 8.41345 20.9547 8.56873L21.1267 8.65343L21.3726 7.43896Z" fill="#00579F" />
                    <path d="M23.8217 13.2971C24.0193 12.7962 24.6748 11.1023 24.6748 11.1023C24.6679 11.1155 24.8172 10.7185 24.9042 10.4699L25.0326 11.0304C25.0326 11.0304 25.4226 12.8437 25.5168 13.2971H23.8217ZM26.3213 7.26514H25.1477C24.713 7.26514 24.3921 7.38741 24.1945 7.82478L20.9824 16.7332H22.8411C22.8411 16.7332 23.2036 15.6291 23.2793 15.4097C23.5044 15.4097 25.4296 15.4097 25.7126 15.4097C25.7746 15.6819 25.9653 16.7332 25.9653 16.7332H27.6329L26.3213 7.26514Z" fill="#00579F" />
                    <path d="M10.4472 7.26514L8.71991 13.6883L8.52401 12.7271C8.17036 11.1947 6.90392 9.53716 5.49805 8.70487L7.09176 16.7265H9.00057L11.9196 7.26514H10.4472Z" fill="#00579F" />
                    <path d="M7.06879 8.07419H4.2666C4.22109 8.08717 4.17578 8.10066 4.13066 8.11463C3.1847 8.22363 2.44984 8.67398 2.44984 8.67398L2.45312 8.72308L5.3849 16.7331H7.29718L8.45604 9.32572C8.45604 9.32572 8.62323 8.43602 8.64559 8.28039C8.13217 8.13775 7.61524 8.05047 7.09556 8.01939C7.08631 8.03566 7.07671 8.05216 7.06879 8.07419Z" fill="#FAA61A" />
                  </svg>
                  <svg className="h-6 w-auto text-slate-400" viewBox="0 0 36 24" fill="none">
                    <rect width="36" height="24" rx="4" fill="#016FD0" />
                    <path d="M18.2342 15.3871H17.7617V12.3437H18.2342V15.3871Z" fill="#FFFFFE" />
                    <path d="M22.9229 12.3437L21.056 14.7529H20.5625V12.3437H19.9014V15.3871H20.5625C20.8042 15.3871 20.9805 15.2764 21.1497 15.0549L21.7893 14.2647V15.3871H22.4503V12.3437H21.7893" fill="#FFFFFE" />
                    <path d="M14.2275 13.8683C14.2275 13.7011 14.1264 13.5752 13.9248 13.5752H13.075V14.1614H13.9248C14.1264 14.1614 14.2275 14.0355 14.2275 13.8683ZM13.075 12.9184H13.9248C14.0754 12.9184 14.2134 12.8075 14.2134 12.6403C14.2134 12.4516 14.0754 12.3408 13.9248 12.3408H12.4139V15.3842H13.075V14.8185H13.5897C13.8408 14.8185 13.9884 14.9078 13.9884 15.1864V15.3842H14.6498V15.0416C14.6498 14.6707 14.4903 14.5163 14.2275 14.4977V14.4862C14.4763 14.4409 14.6498 14.1935 14.6498 13.8596C14.6498 13.368 14.2698 12.9184 13.5968 12.9184H13.075Z" fill="#FFFFFE" />
                    <path d="M15.7682 13.8683C15.7682 13.7011 15.6673 13.5752 15.4658 13.5752H14.616V14.1614H15.4658C15.6673 14.1614 15.7682 14.0355 15.7682 13.8683ZM14.616 12.9184H15.4658C15.6161 12.9184 15.7543 12.8075 15.7543 12.6403C15.7543 12.4516 15.6161 12.3408 15.4658 12.3408H13.9546V15.3842H14.616V14.8185H15.1308C15.3819 14.8185 15.5292 14.9078 15.5292 15.1864V15.3842H16.1908V15.0416C16.1908 14.6707 16.031 14.5163 15.7682 14.4977V14.4862C16.0173 14.4409 16.1908 14.1935 16.1908 13.8596C16.1908 13.368 15.8106 12.9184 15.1376 12.9184H14.616Z" fill="#FFFFFE" />
                    <path fillRule="evenodd" clipRule="evenodd" d="M18 7.51611C16.4921 7.51611 15.274 8.73725 15.274 10.2495C15.274 11.7618 16.4921 12.9829 18 12.9829C19.508 12.9829 20.726 11.7618 20.726 10.2495C20.726 8.73725 19.508 7.51611 18 7.51611ZM18 12.2442C16.8989 12.2442 16.0103 11.3534 16.0103 10.2495C16.0103 9.14559 16.8989 8.25483 18 8.25483C19.1011 8.25483 19.9898 9.14559 19.9898 10.2495C19.9898 11.3534 19.1011 12.2442 18 12.2442Z" fill="#FFFFFE" />
                    <path d="M17.9997 8.99377C17.4301 8.99377 16.9677 9.45804 16.9677 10.0298C16.9677 10.6016 17.4301 11.0659 17.9997 11.0659C18.5694 11.0659 19.0318 10.6016 19.0318 10.0298C19.0318 9.45804 18.5694 8.99377 17.9997 8.99377Z" fill="#016FD0" />
                  </svg>
                </div>
              </div>
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? (
                  <span className="flex items-center">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </span>
                ) : (
                  "Pay Now"
                )}
              </Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}