import AdminDashboard from '@/components/admin/admin-dashboard';
import AuthGuard from '@/components/auth/auth-guard';

export default function AdminPage() {
  return (
    <AuthGuard requireAdmin={true}>
      <div className="min-h-screen bg-background">
        <div className="container py-10">
          <AdminDashboard />
        </div>
      </div>
    </AuthGuard>
  );
}