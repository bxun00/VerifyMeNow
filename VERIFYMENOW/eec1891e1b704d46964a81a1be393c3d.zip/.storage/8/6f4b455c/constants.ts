// Navigation
export const NAV_LINKS = [
  { title: "Home", href: "/" },
  { title: "Features", href: "#features" },
  { title: "Pricing", href: "#pricing" },
  { title: "How It Works", href: "#how-it-works" },
  { title: "About Us", href: "#about" },
  { title: "Contact", href: "#contact" }
];

// Features
export const FEATURES = [
  {
    title: "ID Verification",
    description: "Verify government IDs, passports and driver's licenses with our advanced AI system.",
    icon: "IdCard"
  },
  {
    title: "Certificate Checks",
    description: "Validate professional certifications, diplomas, and credentials in real-time.",
    icon: "FileCheck"
  },
  {
    title: "Criminal Record Lookup",
    description: "Run comprehensive background checks across multiple jurisdictions.",
    icon: "Gavel"
  },
  {
    title: "API Integration",
    description: "Seamlessly integrate our verification services into your existing systems.",
    icon: "Code"
  }
];

// How It Works
export const HOW_IT_WORKS_STEPS = [
  {
    step: 1,
    title: "Upload",
    description: "Upload identification documents or enter information to verify.",
    icon: "Upload"
  },
  {
    step: 2,
    title: "Verify",
    description: "Our AI-powered system analyzes and verifies the information instantly.",
    icon: "CheckCircle"
  },
  {
    step: 3,
    title: "Get Results",
    description: "Receive comprehensive verification results and reports.",
    icon: "FileText"
  }
];

// Pricing Plans
export const PRICING_PLANS = [
  {
    name: "Starter",
    price: 4.99,
    description: "Perfect for individuals needing occasional verification.",
    features: [
      "5 ID verifications per month",
      "Basic reporting",
      "Email support",
      "24-hour results"
    ],
    cta: "Start Free Trial",
    popular: false
  },
  {
    name: "Pro Freelancer",
    price: 9.99,
    description: "Ideal for freelancers and small businesses.",
    features: [
      "25 verifications per month",
      "Advanced reporting",
      "Priority email support",
      "12-hour results",
      "Certificate verification"
    ],
    cta: "Get Pro Plan",
    popular: true
  },
  {
    name: "Tenant Pro",
    price: 14.99,
    description: "Comprehensive solution for property managers.",
    features: [
      "50 verifications per month",
      "Background checks included",
      "Phone support",
      "4-hour results",
      "Certificate verification",
      "Credit checks"
    ],
    cta: "Choose Tenant Pro",
    popular: false
  },
  {
    name: "Company API",
    price: 99.99,
    description: "Enterprise-grade API access for seamless integration.",
    features: [
      "Unlimited verifications",
      "Full API access",
      "Custom integration support",
      "Real-time verification",
      "Dedicated account manager",
      "Custom reporting"
    ],
    cta: "Contact Sales",
    popular: false
  }
];

// Trusted By Logos
export const TRUST_LOGOS = [
  "University of Tech",
  "Homes Property Group",
  "Enterprise Corp",
  "Fast Hiring Inc.",
  "SecureTenant Ltd",
  "Global Staffing"
];

// Social Media Links
export const SOCIAL_LINKS = [
  { name: "Twitter", icon: "Twitter", url: "https://twitter.com" },
  { name: "LinkedIn", icon: "Linkedin", url: "https://linkedin.com" },
  { name: "Facebook", icon: "Facebook", url: "https://facebook.com" },
  { name: "Instagram", icon: "Instagram", url: "https://instagram.com" }
];

// Footer Links
export const FOOTER_LINKS = [
  {
    title: "Company",
    links: [
      { label: "About Us", href: "#about" },
      { label: "Careers", href: "#careers" },
      { label: "Press", href: "#press" },
      { label: "Blog", href: "#blog" }
    ]
  },
  {
    title: "Legal",
    links: [
      { label: "Terms of Service", href: "#terms" },
      { label: "Privacy Policy", href: "#privacy" },
      { label: "Security", href: "#security" },
      { label: "Compliance", href: "#compliance" }
    ]
  },
  {
    title: "Support",
    links: [
      { label: "Help Center", href: "#help" },
      { label: "Contact Us", href: "#contact" },
      { label: "FAQs", href: "#faqs" },
      { label: "System Status", href: "#status" }
    ]
  }
];