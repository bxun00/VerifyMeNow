"use client";

import { useState, useEffect } from "react";
import { Icons } from "@/components/icons";
import { Button } from "@/components/ui/button";
import { NAV_LINKS } from "@/lib/constants";
import { useAuth } from "@/lib/auth";
import { 
  Sheet,
  SheetClose,
  SheetContent, 
  SheetTrigger,
  SheetHeader,
  SheetTitle,
  SheetFooter
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link, useNavigate } from 'react-router-dom';

export function NavBar() {
  const [isScrolled, setIsScrolled] = useState(false);

  // Add scroll listener with proper cleanup
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener("scroll", handleScroll);
    
    // Cleanup event listener on unmount
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-all duration-200 ${
        isScrolled 
          ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-200/50" 
          : "bg-transparent"
      }`}
    >
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <div className="flex items-center gap-2">
          <a href="/" className="flex items-center space-x-2">
            <Icons.Logo className="h-8 w-8 text-blue-600" />
            <span className="font-bold text-xl hidden sm:inline-block">VerifyMeNow</span>
          </a>
          <nav className="hidden lg:flex ml-6 gap-6 text-sm">
            {NAV_LINKS.map((link, index) => (
              <a 
                key={index}
                href={link.href}
                className="text-slate-700 hover:text-blue-700 transition-colors"
              >
                {link.title}
              </a>
            ))}
            <AuthenticatedLinks />
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <AuthButton />
          <MobileNav />
        </div>
      </div>
    </header>
  );
}

function AuthenticatedLinks() {
  const { user, isAuthenticated } = useAuth();
  
  if (!isAuthenticated) return null;
  
  return (
    <>
      <a 
        href="/dashboard" 
        className="text-slate-700 hover:text-blue-700 transition-colors"
      >
        Dashboard
      </a>
      {user?.isAdmin && (
        <a 
          href="/admin" 
          className="text-slate-700 hover:text-blue-700 transition-colors"
        >
          Admin
        </a>
      )}
    </>
  );
}

function AuthButton() {
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  
  // If user is authenticated, show profile button/logout
  if (isAuthenticated && user) {
    return (
      <div className="flex items-center gap-2">
        <span className="text-sm text-slate-600 hidden sm:inline-block">
          Hello, {user.name}
        </span>
        <Button 
          variant="outline" 
          size="sm" 
          className="hidden sm:flex"
          onClick={() => {
            logout();
            navigate('/');
          }}
        >
          Log Out
        </Button>
      </div>
    );
  }
  
  // Otherwise show login/signup options
  return (
    <div className="flex items-center gap-2">
      <Button 
        variant="ghost" 
        size="sm" 
        className="hidden sm:flex"
        onClick={() => navigate('/login')}
      >
        Log In
      </Button>
      <Button 
        variant="default" 
        size="sm" 
        className="hidden sm:flex"
        onClick={() => navigate('/register')}
      >
        Sign Up
      </Button>
    </div>
  );
}

function MobileNav() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  
  const handleLogout = () => {
    setIsOpen(false);
    logout();
    navigate('/');
  };
  
  const navigateTo = (path: string) => {
    setIsOpen(false);
    navigate(path);
  };
  
  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild className="lg:hidden">
        <Button variant="ghost" size="icon" aria-label="Open menu">
          <Icons.Menu className="h-5 w-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-[80vw] sm:w-[350px] pr-0">
        <SheetHeader className="mb-6">
          <SheetTitle className="flex items-center">
            <Icons.Logo className="h-6 w-6 text-blue-600 mr-2" />
            <span>VerifyMeNow</span>
          </SheetTitle>
        </SheetHeader>
        
        <div className="flex flex-col space-y-4 pr-6">
          <div className="flex flex-col space-y-3 mb-6">
            {NAV_LINKS.map((link, index) => (
              <SheetClose asChild key={index}>
                <a
                  href={link.href}
                  className="flex items-center py-2 text-base font-medium text-slate-800 hover:text-blue-700 transition-colors border-b border-gray-100"
                >
                  <span className="ml-2">{link.title}</span>
                </a>
              </SheetClose>
            ))}
            
            {/* Show dashboard and admin links if authenticated */}
            {isAuthenticated && (
              <>
                <SheetClose asChild>
                  <a
                    href="/dashboard"
                    className="flex items-center py-2 text-base font-medium text-slate-800 hover:text-blue-700 transition-colors border-b border-gray-100"
                  >
                    <span className="ml-2">Dashboard</span>
                  </a>
                </SheetClose>
                
                {user?.isAdmin && (
                  <SheetClose asChild>
                    <a
                      href="/admin"
                      className="flex items-center py-2 text-base font-medium text-slate-800 hover:text-blue-700 transition-colors border-b border-gray-100"
                    >
                      <span className="ml-2">Admin</span>
                    </a>
                  </SheetClose>
                )}
              </>
            )}
          </div>
          
          <div className="mt-auto">
            {isAuthenticated ? (
              <div className="space-y-3">
                <div className="text-sm text-slate-600">
                  Logged in as <span className="font-medium">{user?.name}</span>
                </div>
                <Button className="w-full" onClick={handleLogout}>
                  Log Out
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <SheetClose asChild>
                  <Button variant="outline" className="w-full" onClick={() => navigateTo('/login')}>
                    Log In
                  </Button>
                </SheetClose>
                <SheetClose asChild>
                  <Button className="w-full" onClick={() => navigateTo('/register')}>
                    Sign Up
                  </Button>
                </SheetClose>
              </div>
            )}
            
            <div className="text-xs text-center text-gray-500 mt-6">
              © 2025 VerifyMeNow. All rights reserved.
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}