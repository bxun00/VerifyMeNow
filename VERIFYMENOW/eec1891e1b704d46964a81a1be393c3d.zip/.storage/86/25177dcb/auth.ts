// Authentication context and utility functions
import { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// Define user types
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  createdAt: string;
  isAdmin?: boolean; // Convenient property for checking admin role
}

// Auth context type
export interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  error: string | null;
}

// Local storage keys
const USER_STORAGE_KEY = 'verifyme_user';

// Create auth context with default values
export const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  isAuthenticated: false,
  login: async () => false,
  register: async () => false,
  logout: () => {},
  error: null
});

// Simulated authentication API calls
const simulateApiCall = <T>(data: T, shouldSucceed = true, delay = 800): Promise<T> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (shouldSucceed) {
        resolve(data);
      } else {
        reject(new Error('Authentication failed'));
      }
    }, delay);
  });
};

// Auth provider props
export interface AuthProviderProps {
  children: React.ReactNode;
}

// Auth provider component
export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load user from local storage on mount
  useEffect(() => {
    const loadUser = () => {
      const storedUser = localStorage.getItem(USER_STORAGE_KEY);
      if (storedUser) {
        try {
          const parsedUser = JSON.parse(storedUser) as User;
          // Add isAdmin convenience property
          parsedUser.isAdmin = parsedUser.role === 'admin';
          setUser(parsedUser);
        } catch (e) {
          console.error('Failed to parse stored user', e);
          localStorage.removeItem(USER_STORAGE_KEY);
        }
      }
      setIsLoading(false);
    };

    loadUser();
  }, []);

  // Login function
  const login = async (email: string, password: string) => {
    setError(null);
    setIsLoading(true);
    
    try {
      // In a real app, this would be an API call to your auth backend
      // For demo purposes, we'll just accept any non-empty credentials
      if (!email || !password) {
        throw new Error('Email and password are required');
      }
      
      const isAdmin = email.includes('admin');
      const mockUser: User = {
        id: `user_${Date.now()}`,
        email,
        name: email.split('@')[0], // Extract name from email
        role: isAdmin ? 'admin' : 'user', // Simple role assignment
        createdAt: new Date().toISOString(),
        isAdmin // Add convenience property
      };

      // Simulate API delay and potential failure
      await simulateApiCall(mockUser, true);
      
      // Save to local storage
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(mockUser));
      setUser(mockUser);
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  // Register function
  const register = async (name: string, email: string, password: string) => {
    setError(null);
    setIsLoading(true);
    
    try {
      // Validate inputs
      if (!name || !email || !password) {
        throw new Error('Name, email and password are required');
      }
      
      if (password.length < 6) {
        throw new Error('Password must be at least 6 characters');
      }
      
      // Create mock user
      const isAdmin = email.includes('admin');
      const mockUser: User = {
        id: `user_${Date.now()}`,
        email,
        name,
        role: isAdmin ? 'admin' : 'user', // Allow admin creation for demo purposes
        createdAt: new Date().toISOString(),
        isAdmin // Add convenience property
      };

      // Simulate API delay
      await simulateApiCall(mockUser, true);
      
      // Save to local storage
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(mockUser));
      setUser(mockUser);
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem(USER_STORAGE_KEY);
    setUser(null);
  };

  // Context value
  const value: AuthContextType = {
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    register,
    logout,
    error
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Protected route hook
export const useRequireAuth = (redirectTo = '/login') => {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate(redirectTo);
    }
  }, [isAuthenticated, isLoading, navigate, redirectTo]);

  return { isLoading };
};