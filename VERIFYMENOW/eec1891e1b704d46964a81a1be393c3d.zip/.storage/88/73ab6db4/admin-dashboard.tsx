import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Icons } from '@/components/icons';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

// Verification request type
interface VerificationRequest {
  id: string;
  userId: string;
  userName: string;
  email: string;
  type: string;
  status: string;
  dateSubmitted: string;
  dateReviewed?: string;
  documents: string[];
  rejectionReason?: string;
}

// User type
interface UserData {
  id: string;
  name: string;
  email: string;
  role: string;
  status: string;
  dateJoined: string;
  verificationStatus: string;
}

// Mock verification requests data
const mockVerifications: VerificationRequest[] = [
  {
    id: 'vr-001',
    userId: 'user_123',
    userName: 'John Doe',
    email: 'john@example.com',
    type: 'Identity',
    status: 'pending',
    dateSubmitted: '2023-06-15T10:30:00Z',
    documents: ['passport.jpg', 'selfie.jpg']
  },
  {
    id: 'vr-002',
    userId: 'user_456',
    userName: 'Jane Smith',
    email: 'jane@example.com',
    type: 'Address',
    status: 'approved',
    dateSubmitted: '2023-06-14T09:20:00Z',
    dateReviewed: '2023-06-16T11:45:00Z',
    documents: ['utility_bill.pdf']
  },
  {
    id: 'vr-003',
    userId: 'user_789',
    userName: 'Robert Johnson',
    email: 'robert@example.com',
    type: 'Business',
    status: 'rejected',
    dateSubmitted: '2023-06-13T14:10:00Z',
    dateReviewed: '2023-06-15T16:30:00Z',
    documents: ['business_reg.pdf', 'tax_id.jpg'],
    rejectionReason: 'Documents expired'
  },
  {
    id: 'vr-004',
    userId: 'user_101',
    userName: 'Mary Wilson',
    email: 'mary@example.com',
    type: 'Identity',
    status: 'pending',
    dateSubmitted: '2023-06-16T08:45:00Z',
    documents: ['driver_license.jpg', 'selfie.jpg']
  },
  {
    id: 'vr-005',
    userId: 'user_202',
    userName: 'David Brown',
    email: 'david@example.com',
    type: 'Address',
    status: 'approved',
    dateSubmitted: '2023-06-12T11:20:00Z',
    dateReviewed: '2023-06-14T09:30:00Z',
    documents: ['bank_statement.pdf']
  }
];

// Mock users data
const mockUsers: UserData[] = [
  {
    id: 'user_123',
    name: 'John Doe',
    email: 'john@example.com',
    role: 'user',
    status: 'active',
    dateJoined: '2023-05-10T08:30:00Z',
    verificationStatus: 'partial'
  },
  {
    id: 'user_456',
    name: 'Jane Smith',
    email: 'jane@example.com',
    role: 'user',
    status: 'active',
    dateJoined: '2023-05-15T10:20:00Z',
    verificationStatus: 'verified'
  },
  {
    id: 'user_789',
    name: 'Robert Johnson',
    email: 'robert@example.com',
    role: 'user',
    status: 'active',
    dateJoined: '2023-05-20T14:45:00Z',
    verificationStatus: 'rejected'
  },
  {
    id: 'user_101',
    name: 'Mary Wilson',
    email: 'mary@example.com',
    role: 'user',
    status: 'active',
    dateJoined: '2023-06-01T09:15:00Z',
    verificationStatus: 'pending'
  },
  {
    id: 'user_202',
    name: 'David Brown',
    email: 'david@example.com',
    role: 'user',
    status: 'suspended',
    dateJoined: '2023-04-25T11:30:00Z',
    verificationStatus: 'verified'
  },
  {
    id: 'user_303',
    name: 'Sarah Miller',
    email: 'sarah@example.com',
    role: 'admin',
    status: 'active',
    dateJoined: '2023-03-15T08:00:00Z',
    verificationStatus: 'verified'
  }
];

// Helper function to format date
function formatDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Status badge component
function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100',
    approved: 'bg-green-100 text-green-800 hover:bg-green-100',
    rejected: 'bg-red-100 text-red-800 hover:bg-red-100',
    verified: 'bg-green-100 text-green-800 hover:bg-green-100',
    partial: 'bg-blue-100 text-blue-800 hover:bg-blue-100',
    active: 'bg-green-100 text-green-800 hover:bg-green-100',
    suspended: 'bg-red-100 text-red-800 hover:bg-red-100',
  };

  return (
    <Badge className={variants[status] || 'bg-gray-100 text-gray-800'} variant="outline">
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  );
}

// Verification request detail dialog
function VerificationDetailDialog({ verification }: { verification: VerificationRequest }) {
  const [status, setStatus] = useState(verification.status);
  const [notes, setNotes] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  
  const handleUpdateStatus = () => {
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      // In a real app, we would update the verification status in the database
      console.log('Status updated to:', status, 'Notes:', notes);
    }, 1000);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">View Details</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Verification Request Details</DialogTitle>
          <DialogDescription>
            Review the verification request and update its status.
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Request ID</h4>
              <p>{verification.id}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Type</h4>
              <p>{verification.type}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">User</h4>
              <p>{verification.userName}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Email</h4>
              <p>{verification.email}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Date Submitted</h4>
              <p>{formatDate(verification.dateSubmitted)}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Current Status</h4>
              <StatusBadge status={verification.status} />
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-muted-foreground mb-2">Documents</h4>
            <div className="space-y-1">
              {verification.documents.map((doc: string, i: number) => (
                <div key={i} className="flex items-center rounded-md border p-2">
                  <Icons.file className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span className="text-sm">{doc}</span>
                  <Button variant="ghost" size="sm" className="ml-auto h-8 w-8 p-0">
                    <Icons.download className="h-4 w-4" />
                    <span className="sr-only">Download</span>
                  </Button>
                </div>
              ))}
            </div>
          </div>
          
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Update Status</h4>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Notes</h4>
            <Input
              placeholder="Add any notes here..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button type="submit" onClick={handleUpdateStatus} disabled={isProcessing}>
            {isProcessing ? (
              <>
                <Icons.spinner className="mr-2 h-4 w-4 animate-spin" /> Processing
              </>
            ) : (
              'Update Status'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// User detail dialog
function UserDetailDialog({ user }: { user: UserData }) {
  const [status, setStatus] = useState(user.status);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const handleUpdateStatus = () => {
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      // In a real app, we would update the user status in the database
      console.log('User status updated to:', status);
    }, 1000);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">View Details</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>User Details</DialogTitle>
          <DialogDescription>
            View and manage user information
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">User ID</h4>
              <p>{user.id}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Role</h4>
              <p className="capitalize">{user.role}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Name</h4>
              <p>{user.name}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Email</h4>
              <p>{user.email}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Date Joined</h4>
              <p>{formatDate(user.dateJoined)}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Current Status</h4>
              <StatusBadge status={user.status} />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium text-muted-foreground">Verification Status</h4>
              <StatusBadge status={user.verificationStatus} />
            </div>
          </div>
          
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Update Status</h4>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <DialogFooter>
          <Button type="submit" onClick={handleUpdateStatus} disabled={isProcessing}>
            {isProcessing ? (
              <>
                <Icons.spinner className="mr-2 h-4 w-4 animate-spin" /> Processing
              </>
            ) : (
              'Update Status'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Verifications tab content
function VerificationsTab() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');
  
  // Filter verifications based on search term and status filter
  const filteredVerifications = mockVerifications.filter((verification) => {
    const matchesSearch = 
      verification.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      verification.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      verification.id.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesFilter = filter === 'all' || verification.status === filter;
    
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          <Input
            placeholder="Search verifications..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-[300px]"
          />
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button>
          <Icons.refresh className="mr-2 h-4 w-4" />
          Refresh
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Submitted</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredVerifications.length > 0 ? (
                filteredVerifications.map((verification) => (
                  <TableRow key={verification.id}>
                    <TableCell className="font-medium">{verification.id}</TableCell>
                    <TableCell>
                      <div>
                        <p>{verification.userName}</p>
                        <p className="text-xs text-muted-foreground">{verification.email}</p>
                      </div>
                    </TableCell>
                    <TableCell>{verification.type}</TableCell>
                    <TableCell>{formatDate(verification.dateSubmitted)}</TableCell>
                    <TableCell>
                      <StatusBadge status={verification.status} />
                    </TableCell>
                    <TableCell className="text-right">
                      <VerificationDetailDialog verification={verification} />
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    No verifications found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

// Users tab content
function UsersTab() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');
  
  // Filter users based on search term and status filter
  const filteredUsers = mockUsers.filter((user) => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.id.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesFilter = filter === 'all' || user.status === filter;
    
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          <Input
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-[300px]"
          />
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="suspended">Suspended</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button>
          <Icons.refresh className="mr-2 h-4 w-4" />
          Refresh
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Verification</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.length > 0 ? (
                filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.id}</TableCell>
                    <TableCell>
                      <div>
                        <p>{user.name}</p>
                        <p className="text-xs text-muted-foreground">{user.email}</p>
                      </div>
                    </TableCell>
                    <TableCell className="capitalize">{user.role}</TableCell>
                    <TableCell>{formatDate(user.dateJoined)}</TableCell>
                    <TableCell>
                      <StatusBadge status={user.status} />
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={user.verificationStatus} />
                    </TableCell>
                    <TableCell className="text-right">
                      <UserDetailDialog user={user} />
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center">
                    No users found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

// Stats card component
function StatsCard({ title, value, description, icon }: { title: string; value: string; description: string; icon: React.ReactNode }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
}

// Main admin dashboard component
export default function AdminDashboard() {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Admin Dashboard</h2>
          <p className="text-muted-foreground">
            Manage verifications and users on the VerifyMeNow platform.
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <p className="text-sm text-muted-foreground">
            Logged in as <span className="font-medium text-foreground">{user?.name}</span>
          </p>
        </div>
      </div>

      {/* Stats overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Total Verifications"
          value="289"
          description="All time verification requests"
          icon={<Icons.checkCircle className="h-4 w-4 text-muted-foreground" />}
        />
        <StatsCard
          title="Pending Reviews"
          value="12"
          description="+3 since yesterday"
          icon={<Icons.clock className="h-4 w-4 text-yellow-600" />}
        />
        <StatsCard
          title="Total Users"
          value="1,420"
          description="+8% from last month"
          icon={<Icons.users className="h-4 w-4 text-muted-foreground" />}
        />
        <StatsCard
          title="Verification Rate"
          value="92%"
          description="Average approval rate"
          icon={<Icons.barChart className="h-4 w-4 text-green-600" />}
        />
      </div>

      {/* Main content tabs */}
      <Tabs defaultValue="verifications" className="space-y-4">
        <TabsList>
          <TabsTrigger value="verifications">Verification Requests</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
        </TabsList>
        <TabsContent value="verifications">
          <VerificationsTab />
        </TabsContent>
        <TabsContent value="users">
          <UsersTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}