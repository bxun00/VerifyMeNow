import { useEffect } from 'react';
import AdminDashboard from '@/components/admin/admin-dashboard';
import { useAuth, useRequireAuth } from '@/lib/auth';
import { useNavigate } from 'react-router-dom';
import { Icons } from '@/components/icons';

export default function AdminPage() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();
  
  // Check if user is admin
  useEffect(() => {
    if (!isLoading && isAuthenticated && user && user.role !== 'admin') {
      // Redirect non-admin users to dashboard
      navigate('/dashboard');
    }
  }, [user, isAuthenticated, isLoading, navigate]);

  // Require authentication
  const auth = useRequireAuth();
  
  // Show loading state while checking authentication
  if (isLoading || auth.isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Icons.spinner className="h-10 w-10 animate-spin text-blue-600" />
        <span className="sr-only">Loading</span>
      </div>
    );
  }
  
  // Show admin dashboard for admin users
  if (isAuthenticated && user?.role === 'admin') {
    return (
      <div className="container py-10">
        <AdminDashboard />
      </div>
    );
  }
  
  // This should never render due to the redirect in useEffect
  return null;
}